package com.example

import com.example.data.model.*
import com.example.data.repository.DestinationsCatalogue
import com.example.data.repository.GhumiRepository
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testDestinationCatalogueContainsRequiredDestinations() {
        val catalogue = DestinationsCatalogue.initialDestinations
        assertTrue("Catalogue must contain at least 47 destinations", catalogue.size >= 47)

        val requiredNames = listOf(
            "Darjeeling", "Kolkata", "Digha", "Kalimpong", "Dooars", "Sundarbans",
            "Gangtok", "Pelling", "Lachung", "Puri", "Bhubaneswar", "Konark",
            "Manali", "Shimla", "Dharamshala", "Jaipur", "Udaipur", "Jaisalmer",
            "Jodhpur", "North Goa", "South Goa", "Agra", "Varanasi", "Ayodhya",
            "Srinagar", "Gulmarg", "Pahalgam", "Nainital", "Mussoorie", "Rishikesh",
            "Munnar", "Alleppey", "Kochi", "Ooty", "Kodaikanal", "Chennai",
            "Bengaluru", "Mysuru", "Coorg", "Mumbai", "Pune", "Lonavala",
            "Shillong", "Cherrapunji", "Tawang", "Kaziranga", "Majuli"
        )

        val destNames = catalogue.map { it.name }.toSet()
        for (name in requiredNames) {
            assertTrue("Catalogue missing required destination: $name", destNames.contains(name))
        }
    }

    @Test
    fun testPaiseExactSplittingReconciliation() {
        val repo = GhumiRepository()
        val members = listOf(
            TripMember(id = "1", name = "A"),
            TripMember(id = "2", name = "B"),
            TripMember(id = "3", name = "C")
        )

        // ₹100.00 = 10000 paise split among 3 members
        // 10000 / 3 = 3333 with remainder 1 -> [3334, 3333, 3333]
        val splits = repo.splitEquallyAmongMembers(10000L, members)
        assertEquals(3, splits.size)
        val sumPaise = splits.sumOf { it.amountPaise }
        assertEquals(10000L, sumPaise)
        assertEquals(3334L, splits[0].amountPaise)
        assertEquals(3333L, splits[1].amountPaise)
        assertEquals(3333L, splits[2].amountPaise)
    }

    @Test
    fun testPercentageSplittingReconciliation() {
        val repo = GhumiRepository()
        val membersWithPct = listOf(
            Pair(TripMember(id = "1", name = "A"), 33.33),
            Pair(TripMember(id = "2", name = "B"), 33.33),
            Pair(TripMember(id = "3", name = "C"), 33.34)
        )
        val splits = repo.splitByPercentage(10000L, membersWithPct)
        assertEquals(10000L, splits.sumOf { it.amountPaise })
    }

    @Test
    fun testMaxThreePhotosEnforcement() {
        val repo = GhumiRepository()
        val resFail = repo.addOrUpdateMemory(
            tripId = "sample",
            placeName = "Tiger Hill",
            visitDate = "2026-11-10",
            personalStory = "Test",
            photoUris = listOf("uri1", "uri2", "uri3", "uri4"), // 4 photos exceeds 3 limit
            notes = ""
        )
        assertTrue(resFail.isFailure)

        val resSuccess = repo.addOrUpdateMemory(
            tripId = "sample",
            placeName = "Tiger Hill",
            visitDate = "2026-11-10",
            personalStory = "Test",
            photoUris = listOf("uri1", "uri2", "uri3"), // 3 photos allowed
            notes = ""
        )
        assertTrue(resSuccess.isSuccess)
        assertEquals(3, resSuccess.getOrNull()?.photoUris?.size)
    }

    @Test
    fun testDebtTransfersAndSettlement() {
        val repo = GhumiRepository()
        val trip = repo.trips.value.first()
        val transfers = repo.computeDebtTransfers(trip.id)
        assertNotNull(transfers)

        val balances = repo.computeMemberBalances(trip.id)
        val netSum = balances.sumOf { it.netBalancePaise }
        // Net sum across all members in a closed group must always sum to 0
        assertEquals(0L, netSum)
    }
}
