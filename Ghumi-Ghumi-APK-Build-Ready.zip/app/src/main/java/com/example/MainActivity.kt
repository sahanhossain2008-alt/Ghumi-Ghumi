package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.Strings
import com.example.ui.AppScreen
import com.example.ui.GhumiViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: GhumiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                GhumiAppRoot(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GhumiAppRoot(viewModel: GhumiViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()
    val trip by viewModel.currentTrip.collectAsState()
    val trips by viewModel.trips.collectAsState()
    val snackbarMsg by viewModel.snackbarMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var tripMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    // Android Hardware & Gesture Back Navigation
    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = "GG",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Column {
                            Text(
                                text = Strings.get("app_name", lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (trip != null) {
                                Text(
                                    text = trip!!.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    if (currentScreen != AppScreen.HOME &&
                        currentScreen != AppScreen.TRIPS &&
                        currentScreen != AppScreen.EXPLORE &&
                        currentScreen != AppScreen.EXPENSES &&
                        currentScreen != AppScreen.MORE_HUB
                    ) {
                        IconButton(onClick = { viewModel.navigateBack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    // Switch Trip Dropdown
                    if (trips.isNotEmpty()) {
                        Box {
                            TextButton(
                                onClick = { tripMenuExpanded = true },
                                modifier = Modifier.testTag("btn_switch_trip")
                            ) {
                                Icon(Icons.Default.Luggage, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = trip?.name?.take(10) ?: "Trips",
                                    maxLines = 1
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }

                            DropdownMenu(
                                expanded = tripMenuExpanded,
                                onDismissRequest = { tripMenuExpanded = false }
                            ) {
                                trips.forEach { t ->
                                    DropdownMenuItem(
                                        text = { Text(t.name) },
                                        onClick = {
                                            viewModel.selectTrip(t.id)
                                            tripMenuExpanded = false
                                        },
                                        leadingIcon = {
                                            if (t.id == trip?.id) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Language Toggle Action Button
                    TextButton(
                        onClick = { viewModel.toggleLanguage() },
                        modifier = Modifier.testTag("action_toggle_language")
                    ) {
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) "हिं" else "EN",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.HOME,
                    onClick = { viewModel.navigateTo(AppScreen.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = Strings.get("home", lang)) },
                    label = { Text(Strings.get("home", lang)) },
                    modifier = Modifier.testTag("nav_home")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.TRIPS,
                    onClick = { viewModel.navigateTo(AppScreen.TRIPS) },
                    icon = { Icon(Icons.Default.Luggage, contentDescription = Strings.get("trips", lang)) },
                    label = { Text(Strings.get("trips", lang)) },
                    modifier = Modifier.testTag("nav_trips")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.EXPLORE,
                    onClick = { viewModel.navigateTo(AppScreen.EXPLORE) },
                    icon = { Icon(Icons.Default.TravelExplore, contentDescription = Strings.get("explore", lang)) },
                    label = { Text(Strings.get("explore", lang)) },
                    modifier = Modifier.testTag("nav_explore")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.EXPENSES,
                    onClick = { viewModel.navigateTo(AppScreen.EXPENSES) },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = Strings.get("expenses", lang)) },
                    label = { Text(Strings.get("expenses", lang)) },
                    modifier = Modifier.testTag("nav_expenses")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.MORE_HUB ||
                            currentScreen == AppScreen.ITINERARY ||
                            currentScreen == AppScreen.MEMORIES ||
                            currentScreen == AppScreen.BOOKINGS ||
                            currentScreen == AppScreen.PACKING ||
                            currentScreen == AppScreen.NOTES ||
                            currentScreen == AppScreen.SETTINGS,
                    onClick = { viewModel.navigateTo(AppScreen.MORE_HUB) },
                    icon = { Icon(Icons.Default.Widgets, contentDescription = Strings.get("more", lang)) },
                    label = { Text(Strings.get("more", lang)) },
                    modifier = Modifier.testTag("nav_more")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> HomeScreen(viewModel = viewModel)
                AppScreen.TRIPS -> TripsScreen(viewModel = viewModel)
                AppScreen.EXPLORE -> DestinationsScreen(viewModel = viewModel)
                AppScreen.EXPENSES -> ExpensesScreen(viewModel = viewModel)
                AppScreen.ITINERARY -> ItineraryScreen(viewModel = viewModel)
                AppScreen.MEMORIES -> MemoriesScreen(viewModel = viewModel)
                AppScreen.BOOKINGS -> BookingsScreen(viewModel = viewModel)
                AppScreen.PACKING -> PackingScreen(viewModel = viewModel)
                AppScreen.NOTES -> NotesScreen(viewModel = viewModel)
                AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                AppScreen.MORE_HUB -> MoreHubScreen(viewModel = viewModel)
            }
        }
    }
}
