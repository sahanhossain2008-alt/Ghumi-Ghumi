package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.Booking
import com.example.data.model.BookingType
import com.example.data.model.Strings
import com.example.ui.GhumiViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingsScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val trip by viewModel.currentTrip.collectAsState()
    val allBookings by viewModel.bookings.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    val tripBookings = remember(allBookings, trip) {
        if (trip == null) emptyList() else allBookings.filter { it.tripId == trip!!.id }
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("bookings_screen"),
        floatingActionButton = {
            if (trip != null) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_booking")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Booking")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = Strings.get("bookings_manager", lang),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (trip == null) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = Strings.get("no_active_trip", lang), style = MaterialTheme.typography.bodyLarge)
                }
                return@Scaffold
            }

            if (tripBookings.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (lang == AppLanguage.HINDI) "कोई होटल या टिकट बुकिंग नहीं जुड़ी है। '+' दबाएं।" else "No bookings logged yet. Tap '+' to add flights, hotels, or trains.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().testTag("bookings_list")
                ) {
                    items(tripBookings, key = { it.id }) { booking ->
                        BookingCard(
                            booking = booking,
                            lang = lang,
                            onDelete = { viewModel.deleteBooking(booking.id) }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog && trip != null) {
        AddBookingDialog(
            lang = lang,
            onDismiss = { showAddDialog = false },
            onAdd = { type, provider, ref, start, end, cost, notes ->
                viewModel.addBooking(trip!!.id, type, provider, ref, start, end, cost, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun BookingCard(
    booking: Booking,
    lang: AppLanguage,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (lang == AppLanguage.HINDI) booking.type.hiLabel else booking.type.enLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = booking.provider,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "${Strings.get("pnr_ref", lang)}: ${booking.bookingReference}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "🗓️ ${booking.startDateTime}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "₹${String.format(Locale.US, "%.2f", booking.costRupees)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (booking.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = booking.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun AddBookingDialog(
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onAdd: (type: BookingType, provider: String, ref: String, start: String, end: String, cost: Double, notes: String) -> Unit
) {
    var selectedType by remember { mutableStateOf(BookingType.HOTEL) }
    var provider by remember { mutableStateOf("") }
    var ref by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("2026-11-12 02:00 PM") }
    var end by remember { mutableStateOf("2026-11-15 11:00 AM") }
    var costStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("add_booking", lang), fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(if (lang == AppLanguage.HINDI) "प्रकार" else "Type", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(BookingType.HOTEL, BookingType.FLIGHT, BookingType.TRAIN, BookingType.CAR_RENTAL).forEach { type ->
                            FilterChip(
                                selected = selectedType == type,
                                onClick = { selectedType = type },
                                label = { Text(if (lang == AppLanguage.HINDI) type.hiLabel else type.enLabel) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = provider,
                        onValueChange = { provider = it },
                        label = { Text(Strings.get("provider", lang)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_booking_provider")
                    )
                }

                item {
                    OutlinedTextField(
                        value = ref,
                        onValueChange = { ref = it },
                        label = { Text(Strings.get("pnr_ref", lang)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_booking_ref")
                    )
                }

                item {
                    OutlinedTextField(
                        value = costStr,
                        onValueChange = { costStr = it },
                        label = { Text(Strings.get("cost", lang)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_booking_cost")
                    )
                }

                item {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "प्रस्थान / चेक-इन" else "Start / Check-in") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "विवरण" else "Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cost = costStr.toDoubleOrNull() ?: 0.0
                    if (provider.isNotBlank() && ref.isNotBlank()) {
                        onAdd(selectedType, provider, ref, start, end, cost, notes)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_add_booking")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}
