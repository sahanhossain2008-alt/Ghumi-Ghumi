package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.AppLanguage
import com.example.data.model.Strings
import com.example.data.model.TravelMemory
import com.example.ui.GhumiViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoriesScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val trip by viewModel.currentTrip.collectAsState()
    val allMemories by viewModel.memories.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedPhotoForFullscreen by remember { mutableStateOf<String?>(null) }
    var memoryToEdit by remember { mutableStateOf<TravelMemory?>(null) }

    val tripMemories = remember(allMemories, trip) {
        if (trip == null) emptyList() else allMemories.filter { it.tripId == trip!!.id }
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("memories_screen"),
        floatingActionButton = {
            if (trip != null) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_memory")
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add Memory")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = Strings.get("travel_memories", lang),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = Strings.get("max_photos_hint", lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (trip == null) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = Strings.get("no_active_trip", lang), style = MaterialTheme.typography.bodyLarge)
                }
                return@Scaffold
            }

            if (tripMemories.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (lang == AppLanguage.HINDI)
                            "अभी तक कोई संस्मरण नहीं जोड़ा गया है। घूमे गए स्थानों की यादें और तस्वीरें जोड़ने के लिए '+' दबाएं।"
                        else
                            "No travel memories captured yet. Tap '+' to record your experience and photos (max 3)!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize().testTag("memories_list")
                ) {
                    items(tripMemories, key = { it.id }) { memory ->
                        MemoryCard(
                            memory = memory,
                            lang = lang,
                            onPhotoClick = { uri -> selectedPhotoForFullscreen = uri },
                            onDelete = { viewModel.deleteMemory(memory.id) }
                        )
                    }
                }
            }
        }
    }

    // Fullscreen Photo Viewer Dialog
    if (selectedPhotoForFullscreen != null) {
        Dialog(onDismissRequest = { selectedPhotoForFullscreen = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                modifier = Modifier.fillMaxWidth().heightIn(max = 500.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(onClick = { selectedPhotoForFullscreen = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    AsyncImage(
                        model = selectedPhotoForFullscreen,
                        contentDescription = "Fullscreen memory",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }
        }
    }

    // Add Memory Dialog
    if (showAddDialog && trip != null) {
        AddMemoryDialog(
            lang = lang,
            onDismiss = { showAddDialog = false },
            onSave = { place, date, story, photos, notes ->
                viewModel.addOrUpdateMemory(trip!!.id, place, date, story, photos, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun MemoryCard(
    memory: TravelMemory,
    lang: AppLanguage,
    onPhotoClick: (String) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("memory_card_${memory.placeName}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = memory.placeName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "🗓️ ${memory.visitDate}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(
                        Icons.Default.DeleteOutline,
                        contentDescription = "Delete Memory",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Photo Gallery (Max 3)
            if (memory.photoUris.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    memory.photoUris.take(3).forEachIndexed { idx, photoUri ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(90.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onPhotoClick(photoUri) }
                        ) {
                            AsyncImage(
                                model = photoUri,
                                contentDescription = "Photo ${idx + 1}",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == AppLanguage.HINDI) "कोई तस्वीर नहीं जुड़ी है (अधिकतम 3 अनुमत)" else "No photos attached (Max 3 allowed)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            Text(
                text = memory.personalStory,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (memory.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "💡 ${memory.notes}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddMemoryDialog(
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (place: String, date: String, story: String, photos: List<String>, notes: String) -> Unit
) {
    var placeName by remember { mutableStateOf("") }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    var visitDate by remember { mutableStateOf(today) }
    var story by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val photoUris = remember { mutableStateListOf<String>() }

    // Modern Zero-Permission Photo Picker for Gallery/Photos
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null && photoUris.size < 3) {
            photoUris.add(uri.toString())
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("travel_memories", lang), fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = placeName,
                        onValueChange = { placeName = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "घूमे गए स्थान का नाम" else "Visited Place Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_memory_place")
                    )
                }

                item {
                    OutlinedTextField(
                        value = visitDate,
                        onValueChange = { visitDate = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "घूमने की तारीख" else "Visit Date") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Text(
                        text = "${Strings.get("travel_memories", lang)} (${photoUris.size}/3 ${if (lang == AppLanguage.HINDI) "तस्वीरें" else "photos"})",
                        style = MaterialTheme.typography.labelMedium
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        photoUris.forEachIndexed { index, uriStr ->
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                AsyncImage(
                                    model = uriStr,
                                    contentDescription = "Photo $index",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                IconButton(
                                    onClick = { photoUris.removeAt(index) },
                                    modifier = Modifier
                                        .size(20.dp)
                                        .align(Alignment.TopEnd)
                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(12.dp))
                                }
                            }
                        }

                        if (photoUris.size < 3) {
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.size(64.dp).testTag("btn_pick_photo"),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add Photo")
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = story,
                        onValueChange = { story = it },
                        label = { Text(Strings.get("personal_experience", lang)) },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("input_memory_story")
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "टिप्स / स्थानीय विवरण" else "Tips / Local details") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (placeName.isNotBlank() && story.isNotBlank()) {
                        onSave(placeName, visitDate, story, photoUris.toList(), notes)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_save_memory")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}
