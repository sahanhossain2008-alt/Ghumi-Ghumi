package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.GhumiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    TRIPS,
    EXPLORE,
    EXPENSES,
    ITINERARY,
    MEMORIES,
    BOOKINGS,
    PACKING,
    NOTES,
    SETTINGS,
    MORE_HUB
}

data class TripDashboardStats(
    val totalBudget: Double = 0.0,
    val totalSpent: Double = 0.0,
    val remainingBudget: Double = 0.0,
    val budgetUsagePercent: Int = 0,
    val visitedItineraryCount: Int = 0,
    val totalItineraryCount: Int = 0,
    val itineraryProgressPercent: Int = 0,
    val packedItemCount: Int = 0,
    val totalPackingCount: Int = 0,
    val isBudgetWarning80: Boolean = false,
    val isBudgetWarning100: Boolean = false
)

class GhumiViewModel(
    val repository: GhumiRepository = GhumiRepository()
) : ViewModel() {

    // Current navigation screen
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Backstack for custom navigation
    private val screenStack = mutableListOf<AppScreen>()

    // Toast/Snackbar message
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Active state from repository
    val currentUser = repository.currentUser
    val currentLanguage = repository.currentLanguage
    val trips = repository.trips
    val selectedTripId = repository.selectedTripId
    val destinations = repository.destinations
    val itineraryItems = repository.itineraryItems
    val expenses = repository.expenses
    val settlements = repository.settlements
    val memories = repository.memories
    val bookings = repository.bookings
    val packingItems = repository.packingItems
    val sharedNotes = repository.sharedNotes

    // Current active trip
    val currentTrip: StateFlow<Trip?> = combine(trips, selectedTripId) { tripList, selId ->
        tripList.find { it.id == selId } ?: tripList.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Current trip stats
    val dashboardStats: StateFlow<TripDashboardStats> = combine(
        currentTrip,
        expenses,
        itineraryItems,
        packingItems
    ) { trip, allExpenses, allItineraries, allPacking ->
        if (trip == null) return@combine TripDashboardStats()

        val tripExps = allExpenses.filter { it.tripId == trip.id }
        val tripItins = allItineraries.filter { it.tripId == trip.id }
        val tripPacks = allPacking.filter { it.tripId == trip.id }

        val totalSpent = tripExps.sumOf { it.amountInRupees }
        val remaining = (trip.totalBudget - totalSpent).coerceAtLeast(0.0)
        val usagePct = if (trip.totalBudget > 0) ((totalSpent / trip.totalBudget) * 100).toInt() else 0

        val visitedCount = tripItins.count { it.status == ItineraryStatus.VISITED }
        val itinPct = if (tripItins.isNotEmpty()) ((visitedCount.toDouble() / tripItins.size) * 100).toInt() else 0

        val packedCount = tripPacks.count { it.isPacked }

        TripDashboardStats(
            totalBudget = trip.totalBudget,
            totalSpent = totalSpent,
            remainingBudget = remaining,
            budgetUsagePercent = usagePct,
            visitedItineraryCount = visitedCount,
            totalItineraryCount = tripItins.size,
            itineraryProgressPercent = itinPct,
            packedItemCount = packedCount,
            totalPackingCount = tripPacks.size,
            isBudgetWarning80 = usagePct in 80..99,
            isBudgetWarning100 = usagePct >= 100
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TripDashboardStats())

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            screenStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeAt(screenStack.size - 1)
            true
        } else if (_currentScreen.value != AppScreen.HOME) {
            _currentScreen.value = AppScreen.HOME
            true
        } else {
            false
        }
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    fun toggleLanguage() {
        val next = if (currentLanguage.value == AppLanguage.ENGLISH) AppLanguage.HINDI else AppLanguage.ENGLISH
        repository.setLanguage(next)
        showMessage(if (next == AppLanguage.HINDI) "भाषा हिंदी में बदल दी गई" else "Language changed to English")
    }

    fun selectTrip(tripId: String) {
        repository.selectTrip(tripId)
    }

    fun createTrip(name: String, dest: String, start: String, end: String, budget: Double) {
        val newTrip = repository.createTrip(name, dest, start, end, budget)
        showMessage("Trip '${newTrip.name}' created!")
    }

    fun joinTripWithCode(code: String) {
        val result = repository.joinTripByCode(code)
        result.onSuccess {
            showMessage("Joined trip: ${it.name} (${it.inviteCode})")
        }.onFailure {
            showMessage("Error joining trip: ${it.localizedMessage}")
        }
    }

    fun deleteTrip(tripId: String) {
        repository.deleteTrip(tripId)
        showMessage("Trip deleted")
    }

    fun addItineraryItem(tripId: String, day: Int, time: String, title: String, place: String, notes: String) {
        repository.addItineraryItem(tripId, day, time, title, place, notes)
        showMessage("Added to day $day itinerary")
    }

    fun updateItineraryStatus(itemId: String, status: ItineraryStatus) {
        repository.updateItineraryStatus(itemId, status)
    }

    fun addExpense(
        tripId: String,
        title: String,
        amountPaise: Long,
        payerId: String,
        payerName: String,
        date: String,
        category: ExpenseCategory,
        splitType: SplitType,
        splits: List<ExpenseSplit>,
        notes: String
    ) {
        repository.addExpense(tripId, title, amountPaise, payerId, payerName, date, category, splitType, splits, null, notes)
        showMessage("Expense added (₹${amountPaise / 100.0})")
    }

    fun deleteExpense(id: String) {
        repository.deleteExpense(id)
        showMessage("Expense removed")
    }

    fun addSettlement(
        tripId: String,
        fromId: String,
        fromName: String,
        toId: String,
        toName: String,
        amountPaise: Long,
        date: String,
        notes: String
    ) {
        repository.addSettlement(tripId, fromId, fromName, toId, toName, amountPaise, date, notes)
        showMessage("Settlement recorded: $fromName paid ₹${amountPaise / 100.0} to $toName")
    }

    fun addOrUpdateMemory(
        tripId: String,
        place: String,
        date: String,
        story: String,
        photos: List<String>,
        notes: String
    ) {
        val res = repository.addOrUpdateMemory(tripId, place, date, story, photos, notes)
        res.onSuccess {
            showMessage("Travel memory saved for $place")
        }.onFailure {
            showMessage(it.message ?: "Failed to save memory")
        }
    }

    fun deleteMemory(id: String) {
        repository.deleteMemory(id)
        showMessage("Memory deleted")
    }

    fun addBooking(
        tripId: String,
        type: BookingType,
        provider: String,
        ref: String,
        start: String,
        end: String,
        cost: Double,
        notes: String
    ) {
        repository.addBooking(tripId, type, provider, ref, start, end, cost, "Confirmed", notes)
        showMessage("Booking recorded for $provider")
    }

    fun deleteBooking(id: String) {
        repository.deleteBooking(id)
        showMessage("Booking deleted")
    }

    fun togglePackingItem(id: String) {
        repository.togglePackingItem(id)
    }

    fun addPackingItem(tripId: String, category: String, name: String) {
        repository.addPackingItem(tripId, category, name)
        showMessage("Added item: $name")
    }

    fun deletePackingItem(id: String) {
        repository.deletePackingItem(id)
    }

    fun addSharedNote(tripId: String, author: String, title: String, content: String) {
        repository.addSharedNote(tripId, author, title, content)
        showMessage("Note saved")
    }

    fun deleteSharedNote(id: String) {
        repository.deleteSharedNote(id)
    }

    fun addCustomDestination(
        name: String,
        state: String,
        category: DestinationCategory,
        desc: String,
        bestTime: String,
        highlights: List<String>
    ) {
        repository.addCustomDestination(name, state, category, desc, bestTime, highlights)
        showMessage("Destination '$name' added to catalogue!")
    }
}
