package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.Strings
import com.example.ui.AppScreen
import com.example.ui.GhumiViewModel

data class MoreHubItem(
    val screen: AppScreen,
    val titleKey: String,
    val descEn: String,
    val descHi: String,
    val icon: ImageVector,
    val color: Color
)

@Composable
fun MoreHubScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()

    val hubItems = listOf(
        MoreHubItem(
            screen = AppScreen.ITINERARY,
            titleKey = "itinerary",
            descEn = "Day-wise timeline & progress",
            descHi = "दिन-वार कार्यक्रम और प्रगति",
            icon = Icons.Default.EventNote,
            color = MaterialTheme.colorScheme.primary
        ),
        MoreHubItem(
            screen = AppScreen.MEMORIES,
            titleKey = "memories",
            descEn = "Photos (max 3) & stories",
            descHi = "तस्वीरें (अधिकतम 3) और यादें",
            icon = Icons.Default.PhotoLibrary,
            color = MaterialTheme.colorScheme.tertiary
        ),
        MoreHubItem(
            screen = AppScreen.BOOKINGS,
            titleKey = "bookings",
            descEn = "Flights, trains & hotels",
            descHi = "टिकट, ट्रेन और होटल बुकिंग",
            icon = Icons.Default.ConfirmationNumber,
            color = MaterialTheme.colorScheme.secondary
        ),
        MoreHubItem(
            screen = AppScreen.PACKING,
            titleKey = "packing",
            descEn = "Gear & luggage checklist",
            descHi = "सामान और पैकिंग चेकलिस्ट",
            icon = Icons.Default.Checklist,
            color = MaterialTheme.colorScheme.primary
        ),
        MoreHubItem(
            screen = AppScreen.NOTES,
            titleKey = "notes",
            descEn = "Emergency & tips",
            descHi = "आपातकालीन संपर्क और टिप्स",
            icon = Icons.Default.Notes,
            color = MaterialTheme.colorScheme.tertiary
        ),
        MoreHubItem(
            screen = AppScreen.SETTINGS,
            titleKey = "settings",
            descEn = "Language & preferences",
            descHi = "भाषा और प्राथमिकताएं",
            icon = Icons.Default.Settings,
            color = MaterialTheme.colorScheme.secondary
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("more_hub_screen")
    ) {
        Text(
            text = Strings.get("more", lang),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(hubItems) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clickable { viewModel.navigateTo(item.screen) }
                        .testTag("hub_item_${item.titleKey}")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            color = item.color.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(item.icon, contentDescription = null, tint = item.color, modifier = Modifier.size(24.dp))
                            }
                        }

                        Column {
                            Text(
                                text = Strings.get(item.titleKey, lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (lang == AppLanguage.HINDI) item.descHi else item.descEn,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
