package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary: Deep Ocean / Himalayan Teal
val TealPrimaryLight = Color(0xFF006688)
val TealPrimaryDark = Color(0xFF68D8D6)

// Secondary: Warm Sunset Amber / Coral
val AmberSecondaryLight = Color(0xFFD97706)
val AmberSecondaryDark = Color(0xFFFBBF24)

// Tertiary: Forest Pine / Nature Emerald
val ForestTertiaryLight = Color(0xFF0D9488)
val ForestTertiaryDark = Color(0xFF5EEAD4)

// Neutral Backgrounds & Surfaces
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2F7)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)

// Status colors
val StatusPlanned = Color(0xFF0284C7)
val StatusVisited = Color(0xFF16A34A)
val StatusSkipped = Color(0xFF94A3B8)
val StatusRescheduled = Color(0xFFD97706)
