package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.Destination
import com.example.data.model.DestinationCategory
import com.example.data.model.Strings
import com.example.ui.GhumiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DestinationsScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val destinations by viewModel.destinations.collectAsState()
    val trip by viewModel.currentTrip.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<DestinationCategory?>(null) }
    var selectedState by remember { mutableStateOf<String?>(null) }

    var selectedDestinationForDetail by remember { mutableStateOf<Destination?>(null) }
    var showAddCustomDialog by remember { mutableStateOf(false) }

    val allStates = remember(destinations) {
        listOf("All") + destinations.map { it.state }.distinct().sorted()
    }

    val filteredDestinations = remember(destinations, searchQuery, selectedCategory, selectedState) {
        destinations.filter { dest ->
            val matchQuery = searchQuery.isBlank() ||
                    dest.name.contains(searchQuery, ignoreCase = true) ||
                    dest.state.contains(searchQuery, ignoreCase = true) ||
                    dest.description.contains(searchQuery, ignoreCase = true)

            val matchCategory = selectedCategory == null || dest.category == selectedCategory
            val matchState = selectedState == null || selectedState == "All" || dest.state.equals(selectedState, ignoreCase = true)

            matchQuery && matchCategory && matchState
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("destinations_screen"),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddCustomDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_custom_destination")
            ) {
                Icon(Icons.Default.AddLocationAlt, contentDescription = "Add Custom Destination")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header & Search
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = Strings.get("explore", lang),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    placeholder = { Text(Strings.get("search_destinations", lang)) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_search_destinations")
                )
            }

            // Category Filter Chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text(Strings.get("all_categories", lang)) }
                    )
                }

                items(DestinationCategory.values()) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                        label = { Text(if (lang == AppLanguage.HINDI) cat.hiName else cat.enName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // State Filter Scroll
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(allStates) { stateName ->
                    val isSel = (selectedState == null && stateName == "All") || selectedState == stateName
                    SuggestionChip(
                        onClick = { selectedState = if (stateName == "All") null else stateName },
                        label = {
                            Text(
                                text = stateName,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = if (isSel) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // List of Destinations
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize().testTag("destinations_list")
            ) {
                items(filteredDestinations, key = { it.id }) { dest ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedDestinationForDetail = dest }
                            .testTag("destination_card_${dest.name}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = dest.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "📍 ${dest.state}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Surface(
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = if (lang == AppLanguage.HINDI) dest.category.hiName else dest.category.enName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = dest.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Best time to visit
                            Text(
                                text = "⏱️ ${if (lang == AppLanguage.HINDI) "घूमने का सर्वश्रेष्ठ समय" else "Best time"}: ${dest.bestTimeToVisit}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Highlights chips
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                dest.highlights.take(3).forEach { hl ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = hl,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Destination Details Modal with "Add to Itinerary" action
    if (selectedDestinationForDetail != null) {
        val dest = selectedDestinationForDetail!!
        AlertDialog(
            onDismissRequest = { selectedDestinationForDetail = null },
            title = {
                Column {
                    Text(dest.name, fontWeight = FontWeight.Bold)
                    Text("📍 ${dest.state} • ${if (lang == AppLanguage.HINDI) dest.category.hiName else dest.category.enName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(dest.description, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("⏱️ ${dest.bestTimeToVisit}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("✨ ${if (lang == AppLanguage.HINDI) "प्रमुख आकर्षण" else "Key Highlights"}:", fontWeight = FontWeight.SemiBold)
                    dest.highlights.forEach { h ->
                        Text("• $h", style = MaterialTheme.typography.bodySmall)
                    }

                    if (dest.isCustom) {
                        Surface(
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (lang == AppLanguage.HINDI) "उपयोगकर्ता द्वारा जोड़ा गया" else "Custom Added Destination",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        trip?.let { currentTrip ->
                            viewModel.addItineraryItem(
                                tripId = currentTrip.id,
                                day = 1,
                                time = "10:00 AM",
                                title = "Visit ${dest.name}",
                                place = dest.name,
                                notes = "Explore ${dest.highlights.firstOrNull() ?: dest.name}"
                            )
                            viewModel.showMessage("Added ${dest.name} to '${currentTrip.name}'!")
                        } ?: run {
                            viewModel.showMessage("Select or create a trip first to add itinerary items.")
                        }
                        selectedDestinationForDetail = null
                    },
                    modifier = Modifier.testTag("btn_add_dest_to_trip")
                ) {
                    Text(Strings.get("add_to_trip", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedDestinationForDetail = null }) {
                    Text(Strings.get("cancel", lang))
                }
            }
        )
    }

    // Add Custom Destination Modal
    if (showAddCustomDialog) {
        AddCustomDestinationDialog(
            lang = lang,
            onDismiss = { showAddCustomDialog = false },
            onAdd = { name, state, category, desc, bestTime, highlights ->
                viewModel.addCustomDestination(name, state, category, desc, bestTime, highlights)
                showAddCustomDialog = false
            }
        )
    }
}

@Composable
fun AddCustomDestinationDialog(
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onAdd: (name: String, state: String, category: DestinationCategory, desc: String, bestTime: String, highlights: List<String>) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var state by remember { mutableStateOf("") }
    var selectedCat by remember { mutableStateOf(DestinationCategory.MOUNTAINS) }
    var desc by remember { mutableStateOf("") }
    var bestTime by remember { mutableStateOf("October - March") }
    var highlightsStr by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("custom_destination", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "स्थान का नाम" else "Destination Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_custom_dest_name")
                )
                OutlinedTextField(
                    value = state,
                    onValueChange = { state = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "राज्य / केंद्र शासित प्रदेश" else "State / UT") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_custom_dest_state")
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "विवरण" else "Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = bestTime,
                    onValueChange = { bestTime = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "घूमने का समय" else "Best Time to Visit") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = highlightsStr,
                    onValueChange = { highlightsStr = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "आकर्षण (अल्पविराम से अलग करें)" else "Highlights (comma separated)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && state.isNotBlank()) {
                        val hl = highlightsStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                        onAdd(name, state, selectedCat, desc.ifBlank { "Tourist destination in $state" }, bestTime, hl)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_add_custom_dest")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}
