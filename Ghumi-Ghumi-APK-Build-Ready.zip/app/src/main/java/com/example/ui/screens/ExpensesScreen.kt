package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.GhumiRepository
import com.example.ui.GhumiViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val trip by viewModel.currentTrip.collectAsState()
    val allExpenses by viewModel.expenses.collectAsState()
    val allSettlements by viewModel.settlements.collectAsState()
    val stats by viewModel.dashboardStats.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Expenses, 1: Balances & Who Owes, 2: Settlements
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showAddSettlementDialog by remember { mutableStateOf(false) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }

    val tripExpenses = remember(allExpenses, trip) {
        if (trip == null) emptyList() else allExpenses.filter { it.tripId == trip!!.id }
    }

    val tripSettlements = remember(allSettlements, trip) {
        if (trip == null) emptyList() else allSettlements.filter { it.tripId == trip!!.id }
    }

    val memberBalances = remember(trip, allExpenses, allSettlements) {
        if (trip == null) emptyList() else viewModel.repository.computeMemberBalances(trip!!.id)
    }

    val debtTransfers = remember(trip, allExpenses, allSettlements) {
        if (trip == null) emptyList() else viewModel.repository.computeDebtTransfers(trip!!.id)
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("expenses_screen"),
        floatingActionButton = {
            if (trip != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilledTonalButton(
                        onClick = { showAddSettlementDialog = true },
                        modifier = Modifier.testTag("btn_record_settlement_fab")
                    ) {
                        Icon(Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Strings.get("settle_up", lang))
                    }

                    FloatingActionButton(
                        onClick = { showAddExpenseDialog = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("fab_add_expense")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Expense")
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header with CSV export button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = Strings.get("expenses", lang),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )

                if (trip != null && tripExpenses.isNotEmpty()) {
                    OutlinedButton(
                        onClick = {
                            val csvData = viewModel.repository.exportExpensesToCsv(trip!!.id)
                            shareCsvIntent(context, "${trip!!.name.replace(" ", "_")}_expenses.csv", csvData)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_export_csv")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(Strings.get("export_csv", lang))
                    }
                }
            }

            if (trip == null) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = Strings.get("no_active_trip", lang),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                return@Scaffold
            }

            // Budget Summary Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("budget_summary_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = Strings.get("total_spent", lang),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "₹${String.format(Locale.US, "%.2f", stats.totalSpent)}",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = Strings.get("total_budget", lang),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "₹${String.format(Locale.US, "%.2f", stats.totalBudget)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { (stats.budgetUsagePercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (stats.isBudgetWarning100) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${Strings.get("remaining", lang)}: ₹${String.format(Locale.US, "%.2f", stats.remainingBudget)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${stats.budgetUsagePercent}% ${Strings.get("budget_used", lang)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (stats.isBudgetWarning100) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }

                    if (stats.isBudgetWarning100) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = Strings.get("budget_warning_100", lang),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    } else if (stats.isBudgetWarning80) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = Strings.get("budget_warning_80", lang),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Row: Expenses vs Balances vs Settlements
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("${Strings.get("expenses", lang)} (${tripExpenses.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(Strings.get("balances", lang)) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("${Strings.get("settle_up", lang)} (${tripSettlements.size})") }
                )
            }

            // Tab Content
            when (selectedTab) {
                0 -> {
                    // Expenses List
                    if (tripExpenses.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (lang == AppLanguage.HINDI) "अभी तक कोई खर्च नहीं जोड़ा गया है।" else "No expenses logged yet. Tap '+' below to add.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize().testTag("expense_items_list")
                        ) {
                            items(tripExpenses, key = { it.id }) { expense ->
                                ExpenseCard(
                                    expense = expense,
                                    lang = lang,
                                    onDelete = { expenseToDelete = expense }
                                )
                            }
                        }
                    }
                }
                1 -> {
                    // Balances & Debt Settlement (Who owes whom)
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize().testTag("balances_list")
                    ) {
                        item {
                            Text(
                                text = Strings.get("who_owes_whom", lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (debtTransfers.isEmpty()) {
                            item {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = if (lang == AppLanguage.HINDI) "🎉 सभी सदस्यों का हिसाब चुकता है!" else "🎉 All members are all settled up! No debts pending.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(16.dp)
                                    )
                                }
                            }
                        } else {
                            items(debtTransfers) { transfer ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = transfer.fromMemberName,
                                                    fontWeight = FontWeight.Bold,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                                Text(
                                                    text = if (lang == AppLanguage.HINDI) " देगा ➔ " else " owes ➔ ",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Text(
                                                    text = transfer.toMemberName,
                                                    fontWeight = FontWeight.Bold,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                            }
                                        }

                                        Text(
                                            text = "₹${String.format(Locale.US, "%.2f", transfer.amountInRupees)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (lang == AppLanguage.HINDI) "सदस्यवार कुल खर्च और शेयर" else "Member-wise Paid vs Share",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        items(memberBalances) { mb ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = mb.memberName,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "${if (lang == AppLanguage.HINDI) "भुगतान किया" else "Paid"}: ₹${String.format(Locale.US, "%.2f", mb.totalPaidRupees)} | ${if (lang == AppLanguage.HINDI) "शेयर" else "Share"}: ₹${String.format(Locale.US, "%.2f", mb.totalOwedRupees)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Surface(
                                        color = if (mb.netBalancePaise >= 0)
                                            MaterialTheme.colorScheme.primaryContainer
                                        else
                                            MaterialTheme.colorScheme.errorContainer,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        val prefix = if (mb.netBalancePaise > 0) "+" else ""
                                        Text(
                                            text = "$prefix₹${String.format(Locale.US, "%.2f", mb.netBalanceRupees)}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (mb.netBalancePaise >= 0)
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            else
                                                MaterialTheme.colorScheme.onErrorContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Settlements History
                    if (tripSettlements.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (lang == AppLanguage.HINDI) "कोई हिसाब चुकता नहीं दर्ज किया गया है।" else "No settlements recorded yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(tripSettlements, key = { it.id }) { s ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(
                                                text = "${s.fromMemberName} ➔ ${s.toMemberName}",
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Text(
                                                text = "${s.date}${if (s.notes.isNotBlank()) " • " + s.notes else ""}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Text(
                                            text = "₹${String.format(Locale.US, "%.2f", s.amountInRupees)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete Expense Confirmation
    if (expenseToDelete != null) {
        AlertDialog(
            onDismissRequest = { expenseToDelete = null },
            title = { Text(if (lang == AppLanguage.HINDI) "खर्च हटाएं?" else "Delete Expense?") },
            text = { Text("Are you sure you want to remove '${expenseToDelete!!.title}' (₹${expenseToDelete!!.amountInRupees})?") },
            confirmButton = {
                Button(
                    onClick = {
                        expenseToDelete?.let { viewModel.deleteExpense(it.id) }
                        expenseToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(Strings.get("delete", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToDelete = null }) {
                    Text(Strings.get("cancel", lang))
                }
            }
        )
    }

    // Add Expense Dialog
    if (showAddExpenseDialog && trip != null) {
        AddExpenseDialog(
            trip = trip!!,
            lang = lang,
            onDismiss = { showAddExpenseDialog = false },
            onAdd = { title, amtPaise, payerId, payerName, date, category, splitType, splits, notes ->
                viewModel.addExpense(trip!!.id, title, amtPaise, payerId, payerName, date, category, splitType, splits, notes)
                showAddExpenseDialog = false
            }
        )
    }

    // Record Settlement Dialog
    if (showAddSettlementDialog && trip != null) {
        RecordSettlementDialog(
            trip = trip!!,
            lang = lang,
            onDismiss = { showAddSettlementDialog = false },
            onRecord = { fromId, fromName, toId, toName, amtPaise, date, notes ->
                viewModel.addSettlement(trip!!.id, fromId, fromName, toId, toName, amtPaise, date, notes)
                showAddSettlementDialog = false
            }
        )
    }
}

@Composable
fun ExpenseCard(
    expense: Expense,
    lang: AppLanguage,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Receipt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = expense.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${if (lang == AppLanguage.HINDI) expense.category.hiName else expense.category.enName} • ${expense.date}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "₹${String.format(Locale.US, "%.2f", expense.amountInRupees)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "${Strings.get("paid_by", lang)} ${expense.payerName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Split summary chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${if (lang == AppLanguage.HINDI) expense.splitType.hiLabel else expense.splitType.enLabel} (${expense.splits.size} ${if (lang == AppLanguage.HINDI) "लोग" else "members"})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (expense.notes.isNotBlank()) {
                    Text(
                        text = expense.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun AddExpenseDialog(
    trip: Trip,
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onAdd: (
        title: String,
        amountPaise: Long,
        payerId: String,
        payerName: String,
        date: String,
        category: ExpenseCategory,
        splitType: SplitType,
        splits: List<ExpenseSplit>,
        notes: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.FOOD) }
    var selectedPayer by remember { mutableStateOf(trip.members.firstOrNull() ?: TripMember(name = "User")) }
    var splitType by remember { mutableStateOf(SplitType.EQUAL) }
    var notes by remember { mutableStateOf("") }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("add_expense", lang), fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "खर्च का विवरण (शीर्षक)" else "Expense Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_expense_title")
                    )
                }

                item {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "राशि (INR ₹)" else "Amount in INR (₹)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_expense_amount")
                    )
                }

                item {
                    Text(Strings.get("paid_by", lang), style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        trip.members.forEach { m ->
                            FilterChip(
                                selected = selectedPayer.id == m.id,
                                onClick = { selectedPayer = m },
                                label = { Text(m.name, maxLines = 1) }
                            )
                        }
                    }
                }

                item {
                    Text(if (lang == AppLanguage.HINDI) "श्रेणी" else "Category", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(ExpenseCategory.FOOD, ExpenseCategory.TRANSPORT, ExpenseCategory.ACCOMMODATION, ExpenseCategory.TICKETS).forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(if (lang == AppLanguage.HINDI) cat.hiName else cat.enName) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(if (lang == AppLanguage.HINDI) "टिप्पणी / रसीद विवरण" else "Notes / Receipt details") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amtRupees = amountStr.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && amtRupees > 0) {
                        val amtPaise = Math.round(amtRupees * 100.0)
                        val splits = GhumiRepository().splitEquallyAmongMembers(amtPaise, trip.members)
                        onAdd(
                            title,
                            amtPaise,
                            selectedPayer.id,
                            selectedPayer.name,
                            today,
                            selectedCategory,
                            splitType,
                            splits,
                            notes
                        )
                    }
                },
                modifier = Modifier.testTag("btn_confirm_add_expense")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}

@Composable
fun RecordSettlementDialog(
    trip: Trip,
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onRecord: (
        fromId: String,
        fromName: String,
        toId: String,
        toName: String,
        amountPaise: Long,
        date: String,
        notes: String
    ) -> Unit
) {
    if (trip.members.size < 2) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(Strings.get("settle_up", lang)) },
            text = { Text("Need at least 2 trip members to record a settlement.") },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
        )
        return
    }

    var fromMember by remember { mutableStateOf(trip.members[0]) }
    var toMember by remember { mutableStateOf(trip.members.getOrElse(1) { trip.members[0] }) }
    var amountStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("UPI Payment") }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("settle_up", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (lang == AppLanguage.HINDI) "किसने भुगतान किया:" else "Who paid:")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    trip.members.forEach { m ->
                        FilterChip(
                            selected = fromMember.id == m.id,
                            onClick = { fromMember = m },
                            label = { Text(m.name) }
                        )
                    }
                }

                Text(if (lang == AppLanguage.HINDI) "किसको मिला:" else "Paid to:")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    trip.members.filter { it.id != fromMember.id }.forEach { m ->
                        FilterChip(
                            selected = toMember.id == m.id,
                            onClick = { toMember = m },
                            label = { Text(m.name) }
                        )
                    }
                }

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "चुकता राशि (₹)" else "Settled Amount (₹)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_settlement_amount")
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "टिप्पणी / UPI संदर्भ" else "Notes / UPI Ref") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amtRupees = amountStr.toDoubleOrNull() ?: 0.0
                    if (amtRupees > 0 && fromMember.id != toMember.id) {
                        val amtPaise = Math.round(amtRupees * 100.0)
                        onRecord(fromMember.id, fromMember.name, toMember.id, toMember.name, amtPaise, today, notes)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_settlement")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}

fun shareCsvIntent(context: Context, filename: String, csvContent: String) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, csvContent)
        type = "text/plain"
        putExtra(Intent.EXTRA_TITLE, filename)
    }
    val shareIntent = Intent.createChooser(sendIntent, "Share Expense CSV")
    context.startActivity(shareIntent)
}
