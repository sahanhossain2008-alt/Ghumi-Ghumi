package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.PackingItem
import com.example.data.model.Strings
import com.example.ui.GhumiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PackingScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val trip by viewModel.currentTrip.collectAsState()
    val allPacking by viewModel.packingItems.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    val tripPacking = remember(allPacking, trip) {
        if (trip == null) emptyList() else allPacking.filter { it.tripId == trip!!.id }
    }

    val packedCount = remember(tripPacking) { tripPacking.count { it.isPacked } }
    val totalCount = remember(tripPacking) { tripPacking.size }
    val progressPct = if (totalCount > 0) ((packedCount.toDouble() / totalCount) * 100).toInt() else 0

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("packing_screen"),
        floatingActionButton = {
            if (trip != null) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_packing")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Packing Item")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = Strings.get("packing_checklist", lang),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )

                if (trip != null && totalCount > 0) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (lang == AppLanguage.HINDI) "पैकिंग प्रगति" else "Packing Progress",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "$packedCount / $totalCount ($progressPct%)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { (progressPct / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surface
                            )
                        }
                    }
                }
            }

            if (trip == null) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(text = Strings.get("no_active_trip", lang), style = MaterialTheme.typography.bodyLarge)
                }
                return@Scaffold
            }

            if (tripPacking.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (lang == AppLanguage.HINDI) "चेकलिस्ट खाली है। सामान जोड़ने के लिए '+' दबाएं।" else "Checklist empty. Tap '+' to add items to pack.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize().testTag("packing_items_list")
                ) {
                    items(tripPacking, key = { it.id }) { item ->
                        PackingItemRow(
                            item = item,
                            onToggle = { viewModel.togglePackingItem(item.id) },
                            onDelete = { viewModel.deletePackingItem(item.id) }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog && trip != null) {
        AddPackingDialog(
            lang = lang,
            onDismiss = { showAddDialog = false },
            onAdd = { category, name ->
                viewModel.addPackingItem(trip!!.id, category, name)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun PackingItemRow(
    item: PackingItem,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (item.isPacked) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().clickable { onToggle() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Checkbox(
                    checked = item.isPacked,
                    onCheckedChange = { onToggle() }
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = item.itemName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (item.isPacked) FontWeight.Normal else FontWeight.Medium,
                        textDecoration = if (item.isPacked) TextDecoration.LineThrough else TextDecoration.None,
                        color = if (item.isPacked) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = item.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun AddPackingDialog(
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onAdd: (category: String, name: String) -> Unit
) {
    var itemName by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Clothing") }

    val categories = listOf("Clothing", "Documents", "Toiletries", "Electronics", "First Aid", "Custom")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("add_item", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = itemName,
                    onValueChange = { itemName = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "सामान का नाम" else "Item Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_packing_name")
                )

                Text(if (lang == AppLanguage.HINDI) "श्रेणी" else "Category", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, maxLines = 1) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.drop(3).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, maxLines = 1) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (itemName.isNotBlank()) {
                        onAdd(category, itemName)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_add_packing")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}
