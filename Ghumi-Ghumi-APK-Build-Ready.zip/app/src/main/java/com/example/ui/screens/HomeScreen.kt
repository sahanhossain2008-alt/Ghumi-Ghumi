package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Strings
import com.example.ui.AppScreen
import com.example.ui.GhumiViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val trip by viewModel.currentTrip.collectAsState()
    val stats by viewModel.dashboardStats.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()
    val user by viewModel.currentUser.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var showJoinDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Welcome & Profile Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().testTag("welcome_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == AppLanguage.HINDI) "नमस्ते, ${user.name}!" else "Namaste, ${user.name}!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = Strings.get("tagline", lang),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }

                    // Language Quick Toggle Badge
                    FilledTonalButton(
                        onClick = { viewModel.toggleLanguage() },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("home_lang_toggle")
                    ) {
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) "हिंदी" else "English",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Active Trip Card
        item {
            if (trip != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth().testTag("active_trip_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = Strings.get("active_trip", lang).uppercase(Locale.getDefault()),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Surface(
                                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.clickable {
                                    viewModel.showMessage("${Strings.get("copied", lang)}: ${trip!!.inviteCode}")
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Share,
                                        contentDescription = "Share code",
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = trip!!.inviteCode,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = trip!!.name,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "📍 ${trip!!.destinations}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = "🗓️ ${trip!!.startDate}  ➔  ${trip!!.endDate}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Progress bars: Itinerary & Budget
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Itinerary Progress
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = Strings.get("trip_progress", lang),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "${stats.visitedItineraryCount}/${stats.totalItineraryCount} (${stats.itineraryProgressPercent}%)",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { (stats.itineraryProgressPercent / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }

                            // Budget Usage
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = Strings.get("budget_used", lang),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "₹${String.format(Locale.US, "%.0f", stats.totalSpent)} / ₹${String.format(Locale.US, "%.0f", stats.totalBudget)} (${stats.budgetUsagePercent}%)",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (stats.isBudgetWarning100) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { (stats.budgetUsagePercent / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                    color = if (stats.isBudgetWarning100) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }

                        // Budget Warnings
                        if (stats.isBudgetWarning100) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = Strings.get("budget_warning_100", lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        } else if (stats.isBudgetWarning80) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = Strings.get("budget_warning_80", lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = Strings.get("no_active_trip", lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = Strings.get("create_first_trip", lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { showCreateDialog = true },
                                modifier = Modifier.testTag("home_create_trip_btn")
                            ) {
                                Text(Strings.get("create_trip", lang))
                            }
                            OutlinedButton(
                                onClick = { showJoinDialog = true },
                                modifier = Modifier.testTag("home_join_trip_btn")
                            ) {
                                Text(Strings.get("join_trip", lang))
                            }
                        }
                    }
                }
            }
        }

        // Quick Feature Shortcuts Grid
        item {
            Text(
                text = if (lang == AppLanguage.HINDI) "त्वरित टूल्स" else "Trip Hub & Tools",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    title = Strings.get("itinerary", lang),
                    subtitle = "${stats.totalItineraryCount} ${if (lang == AppLanguage.HINDI) "स्थान" else "places"}",
                    icon = Icons.Default.EventNote,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f).testTag("action_itinerary")
                ) {
                    viewModel.navigateTo(AppScreen.ITINERARY)
                }

                QuickActionCard(
                    title = Strings.get("expenses", lang),
                    subtitle = "₹${String.format(Locale.US, "%.0f", stats.totalSpent)}",
                    icon = Icons.Default.AccountBalanceWallet,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f).testTag("action_expenses")
                ) {
                    viewModel.navigateTo(AppScreen.EXPENSES)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    title = Strings.get("memories", lang),
                    subtitle = Strings.get("max_photos_hint", lang),
                    icon = Icons.Default.PhotoLibrary,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f).testTag("action_memories")
                ) {
                    viewModel.navigateTo(AppScreen.MEMORIES)
                }

                QuickActionCard(
                    title = Strings.get("explore", lang),
                    subtitle = if (lang == AppLanguage.HINDI) "47+ भारतीय स्थल" else "47+ Indian spots",
                    icon = Icons.Default.TravelExplore,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f).testTag("action_explore")
                ) {
                    viewModel.navigateTo(AppScreen.EXPLORE)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    title = Strings.get("packing", lang),
                    subtitle = "${stats.packedItemCount}/${stats.totalPackingCount} ${if (lang == AppLanguage.HINDI) "पैक किए" else "packed"}",
                    icon = Icons.Default.Checklist,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f).testTag("action_packing")
                ) {
                    viewModel.navigateTo(AppScreen.PACKING)
                }

                QuickActionCard(
                    title = Strings.get("bookings", lang),
                    subtitle = if (lang == AppLanguage.HINDI) "टिकट और होटल" else "Tickets & Stays",
                    icon = Icons.Default.ConfirmationNumber,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f).testTag("action_bookings")
                ) {
                    viewModel.navigateTo(AppScreen.BOOKINGS)
                }
            }
        }
    }

    // Create Trip Dialog
    if (showCreateDialog) {
        CreateTripDialog(
            lang = lang,
            onDismiss = { showCreateDialog = false },
            onCreate = { name, dest, start, end, budget ->
                viewModel.createTrip(name, dest, start, end, budget)
                showCreateDialog = false
            }
        )
    }

    // Join Trip Dialog
    if (showJoinDialog) {
        JoinTripDialog(
            lang = lang,
            onDismiss = { showJoinDialog = false },
            onJoin = { code ->
                viewModel.joinTripWithCode(code)
                showJoinDialog = false
            }
        )
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun CreateTripDialog(
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onCreate: (name: String, dest: String, start: String, end: String, budget: Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var dest by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("2026-11-20") }
    var end by remember { mutableStateOf("2026-11-25") }
    var budgetStr by remember { mutableStateOf("25000") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("create_trip", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(Strings.get("trip_name", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_trip_name")
                )
                OutlinedTextField(
                    value = dest,
                    onValueChange = { dest = it },
                    label = { Text(Strings.get("destination", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_trip_dest")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it },
                        label = { Text(Strings.get("start_date", lang)) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = { end = it },
                        label = { Text(Strings.get("end_date", lang)) },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = budgetStr,
                    onValueChange = { budgetStr = it },
                    label = { Text(Strings.get("total_budget", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_trip_budget")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onCreate(name, dest.ifBlank { name }, start, end, budgetStr.toDoubleOrNull() ?: 20000.0)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_create_trip")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}

@Composable
fun JoinTripDialog(
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onJoin: (code: String) -> Unit
) {
    var code by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Strings.get("join_trip", lang), fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = Strings.get("enter_invite_code", lang),
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.uppercase() },
                    placeholder = { Text("e.g. GHUMI-PURI-9284") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_join_code")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (code.isNotBlank()) {
                        onJoin(code)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_join_trip")
            ) {
                Text(Strings.get("join_trip", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}
