package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.ItineraryItem
import com.example.data.model.ItineraryStatus
import com.example.data.model.Strings
import com.example.ui.GhumiViewModel
import com.example.ui.theme.StatusPlanned
import com.example.ui.theme.StatusRescheduled
import com.example.ui.theme.StatusSkipped
import com.example.ui.theme.StatusVisited

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItineraryScreen(
    viewModel: GhumiViewModel,
    modifier: Modifier = Modifier
) {
    val trip by viewModel.currentTrip.collectAsState()
    val allItinerary by viewModel.itineraryItems.collectAsState()
    val stats by viewModel.dashboardStats.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()

    var selectedDay by remember { mutableStateOf(1) }
    var showAddDialog by remember { mutableStateOf(false) }

    val tripItinerary = remember(allItinerary, trip) {
        if (trip == null) emptyList() else allItinerary.filter { it.tripId == trip!!.id }
    }

    val dayItems = remember(tripItinerary, selectedDay) {
        tripItinerary.filter { it.dayNumber == selectedDay }
    }

    val maxDays = remember(tripItinerary) {
        (tripItinerary.maxOfOrNull { it.dayNumber } ?: 3).coerceAtLeast(3)
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("itinerary_screen"),
        floatingActionButton = {
            if (trip != null) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_itinerary")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Item")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header & Overall Progress
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = Strings.get("itinerary", lang),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )

                if (trip != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = Strings.get("trip_progress", lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "${stats.visitedItineraryCount} / ${stats.totalItineraryCount} (${stats.itineraryProgressPercent}%)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { (stats.itineraryProgressPercent / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surface
                            )
                        }
                    }
                }
            }

            if (trip == null) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = Strings.get("no_active_trip", lang), style = MaterialTheme.typography.bodyLarge)
                }
                return@Scaffold
            }

            // Day Selector Row
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items((1..maxDays).toList()) { dayNum ->
                    val countForDay = tripItinerary.count { it.dayNumber == dayNum }
                    FilterChip(
                        selected = selectedDay == dayNum,
                        onClick = { selectedDay = dayNum },
                        label = {
                            Text("${Strings.get("day", lang)} $dayNum ($countForDay)")
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Day Items List
            if (dayItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (lang == AppLanguage.HINDI) "दिन $selectedDay के लिए कोई कार्यक्रम नहीं है। '+' दबाकर जोड़ें।" else "No activities planned for Day $selectedDay yet. Tap '+' to add.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().testTag("itinerary_timeline_list")
                ) {
                    items(dayItems, key = { it.id }) { item ->
                        ItineraryItemCard(
                            item = item,
                            lang = lang,
                            onStatusChange = { newStatus ->
                                viewModel.updateItineraryStatus(item.id, newStatus)
                            },
                            onDelete = {
                                viewModel.repository.deleteItineraryItem(item.id)
                                viewModel.showMessage("Removed from itinerary")
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog && trip != null) {
        AddItineraryItemDialog(
            dayNumber = selectedDay,
            lang = lang,
            onDismiss = { showAddDialog = false },
            onAdd = { time, title, place, notes ->
                viewModel.addItineraryItem(trip!!.id, selectedDay, time, title, place, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun ItineraryItemCard(
    item: ItineraryItem,
    lang: AppLanguage,
    onStatusChange: (ItineraryStatus) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("itinerary_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "⏰ ${item.time}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "📍 ${item.placeName}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )

            if (item.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = item.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Status Selector Pills
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ItineraryStatus.values().forEach { st ->
                    val isCurrent = item.status == st
                    val color = when (st) {
                        ItineraryStatus.PLANNED -> StatusPlanned
                        ItineraryStatus.VISITED -> StatusVisited
                        ItineraryStatus.SKIPPED -> StatusSkipped
                        ItineraryStatus.RESCHEDULED -> StatusRescheduled
                    }

                    Surface(
                        color = if (isCurrent) color.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable { onStatusChange(st) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (isCurrent) color else Color.Gray, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (lang == AppLanguage.HINDI) st.hiLabel else st.enLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCurrent) color else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddItineraryItemDialog(
    dayNumber: Int,
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onAdd: (time: String, title: String, place: String, notes: String) -> Unit
) {
    var time by remember { mutableStateOf("10:00 AM") }
    var title by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${Strings.get("add_itinerary", lang)} (${Strings.get("day", lang)} $dayNumber)", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text(Strings.get("time", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(Strings.get("item_title", lang)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_itinerary_title")
                )
                OutlinedTextField(
                    value = place,
                    onValueChange = { place = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "स्थान का नाम" else "Location / Place") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_itinerary_place")
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(if (lang == AppLanguage.HINDI) "मार्गदर्शन या टिप्स" else "Notes or Tips") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onAdd(time, title, place.ifBlank { title }, notes)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_add_itinerary")
            ) {
                Text(Strings.get("save", lang))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Strings.get("cancel", lang))
            }
        }
    )
}
