package com.example.data.repository

import com.example.data.model.Destination
import com.example.data.model.DestinationCategory

object DestinationsCatalogue {
    val initialDestinations: List<Destination> = listOf(
        // West Bengal
        Destination(
            name = "Darjeeling",
            state = "West Bengal",
            category = DestinationCategory.MOUNTAINS,
            description = "Queen of the Hills renowned for tea plantations, Kanchenjunga sunrise views, and the heritage Himalayan Railway.",
            bestTimeToVisit = "March - May, October - December",
            highlights = listOf("Tiger Hill Sunrise", "Batasia Loop", "Happy Valley Tea Estate", "Himalayan Mountaineering Institute")
        ),
        Destination(
            name = "Kolkata",
            state = "West Bengal",
            category = DestinationCategory.CULTURAL,
            description = "City of Joy with magnificent colonial architecture, literary heritage, Durga Puja fervor, and street food.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Victoria Memorial", "Howrah Bridge", "Dakshineswar Temple", "Park Street Food")
        ),
        Destination(
            name = "Digha",
            state = "West Bengal",
            category = DestinationCategory.BEACHES,
            description = "Most popular coastal resort town of Bengal known for its wide flat hard-sand beaches and fresh seafood.",
            bestTimeToVisit = "July - March",
            highlights = listOf("New Digha Beach", "Udaipur Beach", "Marine Aquarium", "Shankarpur Harbor")
        ),
        Destination(
            name = "Kalimpong",
            state = "West Bengal",
            category = DestinationCategory.MOUNTAINS,
            description = "Serene hill station overlooking the Teesta River, famous for orchid nurseries, monasteries, and Tibetan crafts.",
            bestTimeToVisit = "September - December, March - May",
            highlights = listOf("Deolo Hill", "Durpin Monastery", "Cactus Nursery", "Graham's Home")
        ),
        Destination(
            name = "Dooars",
            state = "West Bengal",
            category = DestinationCategory.NATURE,
            description = "Alluvial floodplains in northeastern Bengal along the foothills of Bhutan, lush with tea gardens and sanctuaries.",
            bestTimeToVisit = "October - April",
            highlights = listOf("Gorumara National Park", "Jaldapara Elephant Safari", "Buxa Fort", "Samsing Tea Valleys")
        ),
        Destination(
            name = "Sundarbans",
            state = "West Bengal",
            category = DestinationCategory.NATURE,
            description = "UNESCO World Heritage mangrove forest, home to the Royal Bengal Tiger, estuarine crocodiles, and river dolphins.",
            bestTimeToVisit = "November - February",
            highlights = listOf("Sajnekhali Watch Tower", "Dobanki Canopy Walk", "Boat Safari", "Mangrove Forest Trail")
        ),

        // Sikkim
        Destination(
            name = "Gangtok",
            state = "Sikkim",
            category = DestinationCategory.MOUNTAINS,
            description = "Capital of Sikkim set along a tiered hill slope with views of Mt. Kanchenjunga, vibrant cafes, and Buddhist monasteries.",
            bestTimeToVisit = "September - June",
            highlights = listOf("MG Marg Promenade", "Rumtek Monastery", "Tsomgo Lake", "Banjhakri Falls")
        ),
        Destination(
            name = "Pelling",
            state = "Sikkim",
            category = DestinationCategory.MOUNTAINS,
            description = "Scenic western Sikkim town with breathtaking close-up vistas of snow-capped Kanchenjunga peaks.",
            bestTimeToVisit = "September - May",
            highlights = listOf("Skywalk Pelling", "Pemayangtse Monastery", "Rabdentse Ruins", "Kanchenjunga Falls")
        ),
        Destination(
            name = "Lachung",
            state = "Sikkim",
            category = DestinationCategory.MOUNTAINS,
            description = "High altitude mountain village in North Sikkim, serving as the gateway to the Valley of Flowers and Zero Point.",
            bestTimeToVisit = "March - June, October - December",
            highlights = listOf("Yumthang Valley", "Zero Point Snow Zone", "Lachung Monastery", "Katao Peak")
        ),

        // Odisha
        Destination(
            name = "Puri",
            state = "Odisha",
            category = DestinationCategory.BEACHES,
            description = "Char Dham holy city famous for the Jagannath Temple, glorious golden beach, and annual Rath Yatra festival.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Shree Jagannath Temple", "Golden Sea Beach", "Swargadwar Market", "Raghurajpur Heritage Craft Village")
        ),
        Destination(
            name = "Bhubaneswar",
            state = "Odisha",
            category = DestinationCategory.HERITAGE,
            description = "Temple City of India showcasing ancient Kalinga architectural marvels spanning hundreds of centuries.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Lingaraj Temple", "Udayagiri & Khandagiri Caves", "Mukteswara Temple", "Dhauli Peace Pagoda")
        ),
        Destination(
            name = "Konark",
            state = "Odisha",
            category = DestinationCategory.HERITAGE,
            description = "Home to the monumental 13th-century Sun Temple carved like an enormous chariot with stone wheels.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Sun Temple (UNESCO)", "Chandrabhaga Beach", "Konark Dance Festival", "Marine Drive")
        ),

        // Himachal Pradesh
        Destination(
            name = "Manali",
            state = "Himachal Pradesh",
            category = DestinationCategory.MOUNTAINS,
            description = "Picturesque Himalayan resort town offering snowy adventures, cedar pine forests, and high mountain passes.",
            bestTimeToVisit = "October - June",
            highlights = listOf("Solang Valley", "Atal Tunnel", "Rohtang Pass", "Old Manali Cafes", "Hadimba Temple")
        ),
        Destination(
            name = "Shimla",
            state = "Himachal Pradesh",
            category = DestinationCategory.MOUNTAINS,
            description = "Former British summer capital perched across seven hills, famous for Mall Road and colonial heritage.",
            bestTimeToVisit = "March - June, November - February",
            highlights = listOf("The Ridge & Mall Road", "Jakhoo Temple", "Kalka-Shimla Toy Train", "Kufri Snow Views")
        ),
        Destination(
            name = "Dharamshala",
            state = "Himachal Pradesh",
            category = DestinationCategory.MOUNTAINS,
            description = "Residence of the Dalai Lama and center of Tibetan culture nestled against the majestic Dhauladhar Range.",
            bestTimeToVisit = "September - June",
            highlights = listOf("Tsuglagkhang Complex", "Bhagsunag Waterfall", "Triund Trek", "HPCA Stadium")
        ),

        // Rajasthan
        Destination(
            name = "Jaipur",
            state = "Rajasthan",
            category = DestinationCategory.HERITAGE,
            description = "The Pink City celebrated for grand forts, opulent palaces, astronomical wonders, and bustling bazaars.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Amer Fort", "Hawa Mahal", "City Palace", "Jantar Mantar", "Johari Bazaar")
        ),
        Destination(
            name = "Udaipur",
            state = "Rajasthan",
            category = DestinationCategory.HERITAGE,
            description = "The City of Lakes featuring fairy-tale white marble palaces mirrored in Lake Pichola's tranquil waters.",
            bestTimeToVisit = "October - March",
            highlights = listOf("City Palace Complex", "Lake Pichola Boat Cruise", "Jag Mandir", "Saheliyon-ki-Bari")
        ),
        Destination(
            name = "Jaisalmer",
            state = "Rajasthan",
            category = DestinationCategory.HERITAGE,
            description = "The Golden City rising from the Thar Desert with a living sandstone fort, havelis, and desert dunes.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Jaisalmer Fort", "Sam Sand Dunes Safari", "Patwon Ki Haveli", "Gadisar Lake")
        ),
        Destination(
            name = "Jodhpur",
            state = "Rajasthan",
            category = DestinationCategory.HERITAGE,
            description = "The Blue City watched over by the towering Mehrangarh Fort, with azure alleys and royal cenotaphs.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Mehrangarh Fort", "Jaswant Thada", "Umaid Bhawan Palace", "Clock Tower Market")
        ),

        // Goa
        Destination(
            name = "North Goa",
            state = "Goa",
            category = DestinationCategory.BEACHES,
            description = "Vibrant coastal hub famous for buzzing beaches, water sports, beach shacks, Portuguese forts, and night markets.",
            bestTimeToVisit = "November - March",
            highlights = listOf("Baga Beach", "Anjuna Flea Market", "Fort Aguada", "Chapora Fort", "Calangute")
        ),
        Destination(
            name = "South Goa",
            state = "Goa",
            category = DestinationCategory.BEACHES,
            description = "Pristine, peaceful white sandy shores lined with swaying palm groves and charming Latin quarters.",
            bestTimeToVisit = "November - April",
            highlights = listOf("Palolem Beach", "Colva Beach", "Cabo de Rama Fort", "Dudhsagar Waterfalls")
        ),

        // Uttar Pradesh
        Destination(
            name = "Agra",
            state = "Uttar Pradesh",
            category = DestinationCategory.HERITAGE,
            description = "Mughal capital and home of the world-famous white marble mausoleum, the Taj Mahal.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Taj Mahal", "Agra Fort", "Fatehpur Sikri", "Mehtab Bagh Sunset")
        ),
        Destination(
            name = "Varanasi",
            state = "Uttar Pradesh",
            category = DestinationCategory.RELIGIOUS,
            description = "One of the oldest continuously inhabited cities on Earth, spiritual heart along the sacred River Ganga.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Kashi Vishwanath Temple", "Dashashwamedh Ganga Aarti", "Assi Ghat", "Sarnath")
        ),
        Destination(
            name = "Ayodhya",
            state = "Uttar Pradesh",
            category = DestinationCategory.RELIGIOUS,
            description = "Sacred birthplace of Lord Rama on the banks of Saryu River, featuring the magnificent Ram Mandir.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Shri Ram Janmabhoomi Mandir", "Hanuman Garhi", "Kanak Bhawan", "Saryu Ghat Aarti")
        ),

        // Jammu & Kashmir
        Destination(
            name = "Srinagar",
            state = "Jammu & Kashmir",
            category = DestinationCategory.MOUNTAINS,
            description = "Paradise on Earth famed for tranquil Dal Lake shikaras, romantic Mughal gardens, and walnut-wood houseboats.",
            bestTimeToVisit = "April - October, December - February (Snow)",
            highlights = listOf("Dal Lake Shikara", "Mughal Shalimar Bagh", "Nigeen Lake Houseboats", "Pari Mahal")
        ),
        Destination(
            name = "Gulmarg",
            state = "Jammu & Kashmir",
            category = DestinationCategory.MOUNTAINS,
            description = "Meadow of Flowers transformed into a winter wonderland with the world's highest cable car gondola.",
            bestTimeToVisit = "December - March (Snow), April - June",
            highlights = listOf("Gulmarg Gondola to Apharwat Peak", "Ski Slopes", "Alpather Lake", "St. Mary's Church")
        ),
        Destination(
            name = "Pahalgam",
            state = "Jammu & Kashmir",
            category = DestinationCategory.MOUNTAINS,
            description = "Valley of Shepherds surrounded by alpine meadows, gushing Lidder River, and conifer woodlands.",
            bestTimeToVisit = "April - October",
            highlights = listOf("Betaab Valley", "Aru Valley", "Baisaran Meadow (Mini Switzerland)", "Lidder River")
        ),

        // Uttarakhand
        Destination(
            name = "Nainital",
            state = "Uttarakhand",
            category = DestinationCategory.MOUNTAINS,
            description = "Charming lake district nestled around an eye-shaped emerald lake bordered by green forested mountains.",
            bestTimeToVisit = "March - June, September - November",
            highlights = listOf("Naini Lake Boating", "Naina Devi Temple", "Snow View Point", "Tiffin Top")
        ),
        Destination(
            name = "Mussoorie",
            state = "Uttarakhand",
            category = DestinationCategory.MOUNTAINS,
            description = "Queen of the Hills with colonial estates, cascading waterfalls, and sweeping views of the Doon Valley.",
            bestTimeToVisit = "March - June, September - November",
            highlights = listOf("Kempty Falls", "Mall Road Mussoorie", "Gun Hill Viewpoint", "Camel's Back Road")
        ),
        Destination(
            name = "Rishikesh",
            state = "Uttarakhand",
            category = DestinationCategory.RELIGIOUS,
            description = "Yoga Capital of the World along the roaring Ganga, famous for white-water rafting and sacred evening aartis.",
            bestTimeToVisit = "September - May",
            highlights = listOf("Ram Jhula & Laxman Jhula", "Triveni Ghat Aarti", "River Rafting", "Beatles Ashram")
        ),

        // Kerala
        Destination(
            name = "Munnar",
            state = "Kerala",
            category = DestinationCategory.MOUNTAINS,
            description = "Emerald carpet of rolling tea estates, misty mountain crests, and rare Neelakurinji flora in the Western Ghats.",
            bestTimeToVisit = "September - May",
            highlights = listOf("Eravikulam National Park", "Mattupetty Dam", "Top Station", "Tea Museum")
        ),
        Destination(
            name = "Alleppey",
            state = "Kerala",
            category = DestinationCategory.NATURE,
            description = "Venice of the East renowned for leisurely houseboat cruises through serene backwaters and emerald lagoons.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Backwater Houseboat Cruise", "Alappuzha Beach", "Vembanad Lake", "Marari Beach")
        ),
        Destination(
            name = "Kochi",
            state = "Kerala",
            category = DestinationCategory.CULTURAL,
            description = "Cosmopolitan port city blending Portuguese, Dutch, British, and Chinese history with contemporary art.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Chinese Fishing Nets", "Fort Kochi", "Mattancherry Palace", "Jew Town & Synagogue")
        ),

        // Tamil Nadu
        Destination(
            name = "Ooty",
            state = "Tamil Nadu",
            category = DestinationCategory.MOUNTAINS,
            description = "Queen of Nilgiris with sprawling tea plantations, eucalyptus groves, and the UNESCO Nilgiri Mountain Railway.",
            bestTimeToVisit = "October - June",
            highlights = listOf("Nilgiri Mountain Toy Train", "Ooty Lake", "Botanical Gardens", "Doddabetta Peak")
        ),
        Destination(
            name = "Kodaikanal",
            state = "Tamil Nadu",
            category = DestinationCategory.MOUNTAINS,
            description = "Princess of Hill Stations set amidst misty granite cliffs, wooded slopes, and a star-shaped lake.",
            bestTimeToVisit = "September - May",
            highlights = listOf("Kodai Lake", "Coaker's Walk", "Pillar Rocks", "Silver Cascade Falls")
        ),
        Destination(
            name = "Chennai",
            state = "Tamil Nadu",
            category = DestinationCategory.CULTURAL,
            description = "Gateway to South India known for classical Carnatic music, ancient Dravidian temples, and long sandy beaches.",
            bestTimeToVisit = "November - February",
            highlights = listOf("Marina Beach", "Kapaleeshwarar Temple", "Santhome Basilica", "Government Museum")
        ),

        // Karnataka
        Destination(
            name = "Bengaluru",
            state = "Karnataka",
            category = DestinationCategory.CULTURAL,
            description = "Garden City and tech capital filled with verdant parks, microbreweries, museums, and historical palaces.",
            bestTimeToVisit = "September - March",
            highlights = listOf("Lalbagh Botanical Garden", "Cubbon Park", "Bangalore Palace", "ISKCON Temple")
        ),
        Destination(
            name = "Mysuru",
            state = "Karnataka",
            category = DestinationCategory.HERITAGE,
            description = "City of Palaces celebrated for the illuminated Mysore Palace, sandalwood craft, and grand Dussehra pageantry.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Mysore Palace", "Chamundi Hill", "Brindavan Gardens", "St. Philomena's Cathedral")
        ),
        Destination(
            name = "Coorg",
            state = "Karnataka",
            category = DestinationCategory.MOUNTAINS,
            description = "Scotland of India adorned with fragrant coffee plantations, spice estates, and tumbling waterfalls.",
            bestTimeToVisit = "October - April",
            highlights = listOf("Abbey Falls", "Raja's Seat", "Dubare Elephant Camp", "Namdroling Golden Temple")
        ),

        // Maharashtra
        Destination(
            name = "Mumbai",
            state = "Maharashtra",
            category = DestinationCategory.CULTURAL,
            description = "Financial metropolis and home of Bollywood, Marine Drive's Queen's Necklace, and Victorian Gothic architecture.",
            bestTimeToVisit = "November - February",
            highlights = listOf("Gateway of India", "Marine Drive", "Elephanta Caves", "Chhatrapati Shivaji Maharaj Terminus")
        ),
        Destination(
            name = "Pune",
            state = "Maharashtra",
            category = DestinationCategory.CULTURAL,
            description = "Cultural capital of Maharashtra steeped in Maratha history, academic institutions, and vibrant youth hubs.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Shaniwar Wada", "Aga Khan Palace", "Sinhagad Fort", "Osho Garden")
        ),
        Destination(
            name = "Lonavala",
            state = "Maharashtra",
            category = DestinationCategory.MOUNTAINS,
            description = "Western Ghats weekend retreat celebrated for monsoon waterfalls, ancient Karla caves, and chikki confections.",
            bestTimeToVisit = "July - September (Monsoon), October - March",
            highlights = listOf("Tiger's Leap Point", "Bhushi Dam", "Karla & Bhaja Caves", "Lonavala Lake")
        ),

        // Northeast India
        Destination(
            name = "Shillong",
            state = "Meghalaya",
            category = DestinationCategory.MOUNTAINS,
            description = "Scotland of the East, blessed with rolling pine hills, living waterfalls, and an energetic indie music scene.",
            bestTimeToVisit = "September - May",
            highlights = listOf("Umiam Lake", "Elephant Falls", "Shillong Peak", "Police Bazar")
        ),
        Destination(
            name = "Cherrapunji",
            state = "Meghalaya",
            category = DestinationCategory.NATURE,
            description = "One of the wettest places on Earth, world-famous for bio-engineered double-decker living root bridges.",
            bestTimeToVisit = "September - May",
            highlights = listOf("Double Decker Living Root Bridge", "Nohkalikai Falls", "Mawsmai Cave", "Seven Sisters Falls")
        ),
        Destination(
            name = "Tawang",
            state = "Arunachal Pradesh",
            category = DestinationCategory.MOUNTAINS,
            description = "Majestic Himalayan mountain town holding India's largest Buddhist monastery and high altitude Sela Pass.",
            bestTimeToVisit = "March - June, September - October",
            highlights = listOf("Tawang Monastery", "Sela Pass & Sela Lake", "Madhuri Lake", "Tawang War Memorial")
        ),
        Destination(
            name = "Kaziranga",
            state = "Assam",
            category = DestinationCategory.NATURE,
            description = "UNESCO World Heritage floodplains sheltering two-thirds of the planet's great one-horned rhinoceroses.",
            bestTimeToVisit = "November - April",
            highlights = listOf("Jeep Safari", "One-Horned Rhinoceros Spotting", "Wild Water Buffalos", "Orchid Park")
        ),
        Destination(
            name = "Majuli",
            state = "Assam",
            category = DestinationCategory.CULTURAL,
            description = "World's largest river island formed on the mighty Brahmaputra, center of Neo-Vaishnavite Satra culture and mask making.",
            bestTimeToVisit = "October - March",
            highlights = listOf("Kamalabari Satra", "Traditional Mask Making at Samaguri", "Migratory Bird Watching", "Brahmaputra Sunset")
        )
    )
}
