package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

class GhumiRepository {

    // Current logged in user
    private val _currentUser = MutableStateFlow(
        User(id = "user_1", name = "Rahul Sharma", email = "rahul@example.com", phone = "+91 9876543210")
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    // Current app language
    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Trips
    private val _trips = MutableStateFlow<List<Trip>>(emptyList())
    val trips: StateFlow<List<Trip>> = _trips.asStateFlow()

    private val _selectedTripId = MutableStateFlow<String?>(null)
    val selectedTripId: StateFlow<String?> = _selectedTripId.asStateFlow()

    // Destinations
    private val _destinations = MutableStateFlow<List<Destination>>(DestinationsCatalogue.initialDestinations)
    val destinations: StateFlow<List<Destination>> = _destinations.asStateFlow()

    // Itinerary items
    private val _itineraryItems = MutableStateFlow<List<ItineraryItem>>(emptyList())
    val itineraryItems: StateFlow<List<ItineraryItem>> = _itineraryItems.asStateFlow()

    // Expenses
    private val _expenses = MutableStateFlow<List<Expense>>(emptyList())
    val expenses: StateFlow<List<Expense>> = _expenses.asStateFlow()

    // Settlements
    private val _settlements = MutableStateFlow<List<Settlement>>(emptyList())
    val settlements: StateFlow<List<Settlement>> = _settlements.asStateFlow()

    // Travel Memories
    private val _memories = MutableStateFlow<List<TravelMemory>>(emptyList())
    val memories: StateFlow<List<TravelMemory>> = _memories.asStateFlow()

    // Bookings
    private val _bookings = MutableStateFlow<List<Booking>>(emptyList())
    val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

    // Packing Items
    private val _packingItems = MutableStateFlow<List<PackingItem>>(emptyList())
    val packingItems: StateFlow<List<PackingItem>> = _packingItems.asStateFlow()

    // Shared Notes
    private val _sharedNotes = MutableStateFlow<List<SharedNote>>(emptyList())
    val sharedNotes: StateFlow<List<SharedNote>> = _sharedNotes.asStateFlow()

    init {
        loadStarterData()
    }

    private fun loadStarterData() {
        val sampleTripId = "trip_darjeeling_2026"
        val member1 = TripMember(id = "user_1", name = "Rahul (Lead)", email = "rahul@example.com", isOwner = true)
        val member2 = TripMember(id = "user_2", name = "Priya Roy", email = "priya@example.com", isOwner = false)
        val member3 = TripMember(id = "user_3", name = "Amit Verma", email = "amit@example.com", isOwner = false)
        val member4 = TripMember(id = "user_4", name = "Sneha Sen", email = "sneha@example.com", isOwner = false)

        val starterTrip = Trip(
            id = sampleTripId,
            name = "Darjeeling & Gangtok Himalayan Odyssey",
            destinations = "Darjeeling, Kalimpong, Gangtok",
            startDate = "2026-11-10",
            endDate = "2026-11-16",
            totalBudget = 45000.0,
            inviteCode = "GHUMI-DARJ-4290",
            ownerId = "user_1",
            members = listOf(member1, member2, member3, member4),
            warningThresholdPercent = 80
        )

        _trips.value = listOf(starterTrip)
        _selectedTripId.value = sampleTripId

        // Itinerary
        _itineraryItems.value = listOf(
            ItineraryItem(
                tripId = sampleTripId,
                dayNumber = 1,
                time = "09:30 AM",
                title = "Arrival at Bagdogra & Shared Taxi to Darjeeling",
                placeName = "Bagdogra Airport",
                notes = "Pre-booked 7-seater SUV via Rohini Highway route",
                status = ItineraryStatus.VISITED
            ),
            ItineraryItem(
                tripId = sampleTripId,
                dayNumber = 1,
                time = "05:00 PM",
                title = "Chowrasta Mall Road Walk & Glenary's Bakery",
                placeName = "Darjeeling Mall",
                notes = "Taste fresh Darjeeling first-flush tea & apple pie",
                status = ItineraryStatus.VISITED
            ),
            ItineraryItem(
                tripId = sampleTripId,
                dayNumber = 2,
                time = "04:30 AM",
                title = "Tiger Hill Kanchenjunga Sunrise",
                placeName = "Tiger Hill",
                notes = "Need warm jackets; sunrise expected at 5:15 AM",
                status = ItineraryStatus.VISITED
            ),
            ItineraryItem(
                tripId = sampleTripId,
                dayNumber = 2,
                time = "10:30 AM",
                title = "Batasia Loop & Ghoom Monastery",
                placeName = "Ghoom",
                notes = "Watch toy train steam engine circle the war memorial",
                status = ItineraryStatus.PLANNED
            ),
            ItineraryItem(
                tripId = sampleTripId,
                dayNumber = 3,
                time = "08:00 AM",
                title = "Transfer to Gangtok via Teesta River Overlook",
                placeName = "Kalimpong - Teesta",
                notes = "Stop at Teesta bazaar for momos and ginger tea",
                status = ItineraryStatus.PLANNED
            ),
            ItineraryItem(
                tripId = sampleTripId,
                dayNumber = 4,
                time = "09:00 AM",
                title = "Tsomgo Glacial Lake & Baba Mandir Excursion",
                placeName = "Tsomgo Lake",
                notes = "Permits organized by travel desk yesterday",
                status = ItineraryStatus.PLANNED
            )
        )

        // Expenses
        val exp1Splits = splitEquallyAmongMembers(
            amountPaise = 640000L, // ₹6,400.00
            members = listOf(member1, member2, member3, member4)
        )
        val exp1 = Expense(
            tripId = sampleTripId,
            title = "SUV Rental Bagdogra to Darjeeling",
            amountPaise = 640000L,
            payerId = "user_1",
            payerName = "Rahul (Lead)",
            date = "2026-11-10",
            category = ExpenseCategory.TRANSPORT,
            splitType = SplitType.EQUAL,
            splits = exp1Splits,
            notes = "Toll and driver tip included"
        )

        val exp2Splits = splitEquallyAmongMembers(
            amountPaise = 320000L, // ₹3,200.00
            members = listOf(member1, member2, member3, member4)
        )
        val exp2 = Expense(
            tripId = sampleTripId,
            title = "Dinner at Glenary's Restaurant & Pub",
            amountPaise = 320000L,
            payerId = "user_2",
            payerName = "Priya Roy",
            date = "2026-11-10",
            category = ExpenseCategory.FOOD,
            splitType = SplitType.EQUAL,
            splits = exp2Splits,
            notes = "Continental dinner and dessert"
        )

        val exp3Splits = splitEquallyAmongMembers(
            amountPaise = 180000L, // ₹1,800.00
            members = listOf(member1, member2, member3, member4)
        )
        val exp3 = Expense(
            tripId = sampleTripId,
            title = "Tiger Hill Observatory Pass & Jeep",
            amountPaise = 180000L,
            payerId = "user_3",
            payerName = "Amit Verma",
            date = "2026-11-11",
            category = ExpenseCategory.TICKETS,
            splitType = SplitType.EQUAL,
            splits = exp3Splits,
            notes = "VIP sunrise deck entry"
        )

        _expenses.value = listOf(exp1, exp2, exp3)

        // Settlements: Amit paid Rahul ₹1,000 as partial advance
        _settlements.value = listOf(
            Settlement(
                tripId = sampleTripId,
                fromMemberId = "user_3",
                fromMemberName = "Amit Verma",
                toMemberId = "user_1",
                toMemberName = "Rahul (Lead)",
                amountPaise = 100000L, // ₹1,000.00
                date = "2026-11-10",
                notes = "UPI Transfer ref #92348102"
            )
        )

        // Memories
        _memories.value = listOf(
            TravelMemory(
                tripId = sampleTripId,
                placeName = "Tiger Hill Sunrise",
                visitDate = "2026-11-11",
                personalStory = "Woke up at 3:45 AM in freezing fog. As the first orange rays hit Kanchenjunga peak, the entire Himalayan range turned golden pink. Absolutely unforgettable moment with the gang!",
                photoUris = listOf(),
                notes = "Temperature was 4°C. Don't miss steaming ginger cardamom tea from local vendors."
            ),
            TravelMemory(
                tripId = sampleTripId,
                placeName = "Glenary's Bakery & Mall Road",
                visitDate = "2026-11-10",
                personalStory = "Walked through misty colonial avenues under warm lampposts. Enjoyed wood-fired pizza and freshly baked pastries with acoustic live guitar music.",
                photoUris = listOf(),
                notes = "Buy Darjeeling Muscatel tea packets from Golden Tips nearby."
            )
        )

        // Bookings
        _bookings.value = listOf(
            Booking(
                tripId = sampleTripId,
                type = BookingType.HOTEL,
                provider = "Cedar Inn Darjeeling",
                bookingReference = "HTL-DAR-88319",
                startDateTime = "2026-11-10 12:00 PM",
                endDateTime = "2026-11-13 11:00 AM",
                costRupees = 18500.0,
                status = "Confirmed",
                notes = "2 Deluxe Rooms with Kanchenjunga view and breakfast"
            ),
            Booking(
                tripId = sampleTripId,
                type = BookingType.CAR_RENTAL,
                provider = "Himalayan Wheels Cabs",
                bookingReference = "CAB-SIL-209",
                startDateTime = "2026-11-10 09:00 AM",
                endDateTime = "2026-11-16 06:00 PM",
                costRupees = 16000.0,
                status = "Confirmed",
                notes = "Innova Crysta AC with experienced hill driver"
            )
        )

        // Packing
        _packingItems.value = listOf(
            PackingItem(tripId = sampleTripId, category = "Clothing", itemName = "Heavy Woolen Jacket / Thermal innerwear", isPacked = true),
            PackingItem(tripId = sampleTripId, category = "Clothing", itemName = "Comfortable Trekking Shoes & Woolen Socks", isPacked = true),
            PackingItem(tripId = sampleTripId, category = "Documents", itemName = "Aadhaar Card / Voter ID for Sikkim Permits", isPacked = true),
            PackingItem(tripId = sampleTripId, category = "Documents", itemName = "Passport-size photos (4 each for Nathula Pass)", isPacked = false),
            PackingItem(tripId = sampleTripId, category = "Electronics", itemName = "Power bank 20,000 mAh & Camera batteries", isPacked = true),
            PackingItem(tripId = sampleTripId, category = "First Aid", itemName = "Altitude sickness tablets (Diamox), Band-Aids & ORS", isPacked = true),
            PackingItem(tripId = sampleTripId, category = "Toiletries", itemName = "Sunscreen SPF 50 & Lip Balm with moisturizer", isPacked = false)
        )

        // Shared Notes
        _sharedNotes.value = listOf(
            SharedNote(
                tripId = sampleTripId,
                authorName = "Rahul",
                title = "Emergency Contacts & Driver Info",
                content = "Driver: Pemba Bhutia (+91 94340 XXXXX). Bagdogra Airport helpdesk: 0353-2698404. Hotel front desk: +91 354 2254446.",
                dateUpdated = "2026-11-09"
            ),
            SharedNote(
                tripId = sampleTripId,
                authorName = "Priya",
                title = "Must-try Local Foods & Souvenirs",
                content = "1. Thukpa & Tingmo at Kunga Restaurant\n2. Churpee (yak cheese snack)\n3. Handwoven Lepcha shawls at Mahakal market\n4. Fresh high-grown orange honey.",
                dateUpdated = "2026-11-10"
            )
        )
    }

    // Language
    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    // Trips
    fun selectTrip(tripId: String) {
        _selectedTripId.value = tripId
    }

    fun createTrip(
        name: String,
        destinations: String,
        startDate: String,
        endDate: String,
        totalBudget: Double,
        coverImageUrl: String = ""
    ): Trip {
        val user = _currentUser.value
        val leadMember = TripMember(id = user.id, name = "${user.name} (Lead)", email = user.email, isOwner = true)
        val newTrip = Trip(
            name = name,
            destinations = destinations,
            startDate = startDate,
            endDate = endDate,
            totalBudget = totalBudget,
            coverImageUrl = coverImageUrl,
            ownerId = user.id,
            members = listOf(leadMember)
        )
        _trips.value = _trips.value + newTrip
        _selectedTripId.value = newTrip.id
        return newTrip
    }

    fun joinTripByCode(code: String): Result<Trip> {
        val trimmed = code.trim().uppercase()
        val found = _trips.value.find { it.inviteCode.equals(trimmed, ignoreCase = true) }
        return if (found != null) {
            val user = _currentUser.value
            val alreadyMember = found.members.any { it.id == user.id }
            if (!alreadyMember) {
                val updatedMembers = found.members + TripMember(id = user.id, name = user.name, email = user.email, isOwner = false)
                val updatedTrip = found.copy(members = updatedMembers)
                _trips.value = _trips.value.map { if (it.id == found.id) updatedTrip else it }
                _selectedTripId.value = updatedTrip.id
                Result.success(updatedTrip)
            } else {
                _selectedTripId.value = found.id
                Result.success(found)
            }
        } else {
            // Simulate accepting a friend's trip code by discovering or creating a linked trip
            val destGuess = trimmed.split("-").getOrNull(1) ?: "GOA"
            val user = _currentUser.value
            val joinedTrip = Trip(
                name = "Group Tour ($destGuess)",
                destinations = destGuess.replace("X", ""),
                startDate = "2026-12-01",
                endDate = "2026-12-06",
                totalBudget = 30000.0,
                inviteCode = trimmed,
                ownerId = "remote_friend",
                members = listOf(
                    TripMember(id = "remote_friend", name = "Trip Host", isOwner = true),
                    TripMember(id = user.id, name = user.name, email = user.email, isOwner = false)
                )
            )
            _trips.value = _trips.value + joinedTrip
            _selectedTripId.value = joinedTrip.id
            Result.success(joinedTrip)
        }
    }

    fun addMemberToTrip(tripId: String, name: String, email: String = "") {
        val trip = _trips.value.find { it.id == tripId } ?: return
        val newMember = TripMember(name = name, email = email, isOwner = false)
        val updated = trip.copy(members = trip.members + newMember)
        _trips.value = _trips.value.map { if (it.id == tripId) updated else it }
    }

    fun deleteTrip(tripId: String) {
        _trips.value = _trips.value.filter { it.id != tripId }
        _itineraryItems.value = _itineraryItems.value.filter { it.tripId != tripId }
        _expenses.value = _expenses.value.filter { it.tripId != tripId }
        _settlements.value = _settlements.value.filter { it.tripId != tripId }
        _memories.value = _memories.value.filter { it.tripId != tripId }
        _bookings.value = _bookings.value.filter { it.tripId != tripId }
        _packingItems.value = _packingItems.value.filter { it.tripId != tripId }
        _sharedNotes.value = _sharedNotes.value.filter { it.tripId != tripId }

        if (_selectedTripId.value == tripId) {
            _selectedTripId.value = _trips.value.firstOrNull()?.id
        }
    }

    // Destinations
    fun addCustomDestination(
        name: String,
        state: String,
        category: DestinationCategory,
        description: String,
        bestTimeToVisit: String,
        highlights: List<String>
    ): Destination {
        val newDest = Destination(
            name = name,
            state = state,
            category = category,
            description = description,
            bestTimeToVisit = bestTimeToVisit,
            highlights = highlights,
            isCustom = true
        )
        _destinations.value = listOf(newDest) + _destinations.value
        return newDest
    }

    // Itinerary
    fun addItineraryItem(
        tripId: String,
        dayNumber: Int,
        time: String,
        title: String,
        placeName: String,
        notes: String
    ): ItineraryItem {
        val item = ItineraryItem(
            tripId = tripId,
            dayNumber = dayNumber,
            time = time,
            title = title,
            placeName = placeName,
            notes = notes,
            status = ItineraryStatus.PLANNED
        )
        _itineraryItems.value = _itineraryItems.value + item
        return item
    }

    fun updateItineraryStatus(itemId: String, status: ItineraryStatus) {
        _itineraryItems.value = _itineraryItems.value.map {
            if (it.id == itemId) it.copy(status = status) else it
        }
    }

    fun deleteItineraryItem(itemId: String) {
        _itineraryItems.value = _itineraryItems.value.filter { it.id != itemId }
    }

    // Expenses & Splits Calculation (Paise Exact)
    fun splitEquallyAmongMembers(amountPaise: Long, members: List<TripMember>): List<ExpenseSplit> {
        if (members.isEmpty()) return emptyList()
        val count = members.size
        val baseShare = amountPaise / count
        val remainder = amountPaise % count

        return members.mapIndexed { index, member ->
            // Distribute remaining paise 1-by-1 to first 'remainder' members
            val share = baseShare + if (index < remainder) 1L else 0L
            val pct = (share.toDouble() / amountPaise.toDouble()) * 100.0
            ExpenseSplit(
                memberId = member.id,
                memberName = member.name,
                amountPaise = share,
                percentage = pct
            )
        }
    }

    fun splitByPercentage(amountPaise: Long, membersWithPct: List<Pair<TripMember, Double>>): List<ExpenseSplit> {
        if (membersWithPct.isEmpty()) return emptyList()
        var allocated = 0L
        val splits = mutableListOf<ExpenseSplit>()

        membersWithPct.forEachIndexed { index, (member, pct) ->
            if (index == membersWithPct.size - 1) {
                // Last member absorbs rounding difference to reconcile exactly with total
                val share = amountPaise - allocated
                splits.add(
                    ExpenseSplit(
                        memberId = member.id,
                        memberName = member.name,
                        amountPaise = share,
                        percentage = pct
                    )
                )
            } else {
                val share = Math.round((pct / 100.0) * amountPaise)
                allocated += share
                splits.add(
                    ExpenseSplit(
                        memberId = member.id,
                        memberName = member.name,
                        amountPaise = share,
                        percentage = pct
                    )
                )
            }
        }
        return splits
    }

    fun addExpense(
        tripId: String,
        title: String,
        amountPaise: Long,
        payerId: String,
        payerName: String,
        date: String,
        category: ExpenseCategory,
        splitType: SplitType,
        splits: List<ExpenseSplit>,
        receiptUri: String? = null,
        notes: String = ""
    ): Expense {
        val expense = Expense(
            tripId = tripId,
            title = title,
            amountPaise = amountPaise,
            payerId = payerId,
            payerName = payerName,
            date = date,
            category = category,
            splitType = splitType,
            splits = splits,
            receiptUri = receiptUri,
            notes = notes
        )
        _expenses.value = _expenses.value + expense
        return expense
    }

    fun deleteExpense(expenseId: String) {
        _expenses.value = _expenses.value.filter { it.id != expenseId }
    }

    // Settlements
    fun addSettlement(
        tripId: String,
        fromMemberId: String,
        fromMemberName: String,
        toMemberId: String,
        toMemberName: String,
        amountPaise: Long,
        date: String,
        notes: String = ""
    ): Settlement {
        val settlement = Settlement(
            tripId = tripId,
            fromMemberId = fromMemberId,
            fromMemberName = fromMemberName,
            toMemberId = toMemberId,
            toMemberName = toMemberName,
            amountPaise = amountPaise,
            date = date,
            notes = notes
        )
        _settlements.value = _settlements.value + settlement
        return settlement
    }

    fun deleteSettlement(settlementId: String) {
        _settlements.value = _settlements.value.filter { it.id != settlementId }
    }

    // Calculate Balances & "Who Owes Whom"
    fun computeMemberBalances(tripId: String): List<MemberBalance> {
        val trip = _trips.value.find { it.id == tripId } ?: return emptyList()
        val tripExpenses = _expenses.value.filter { it.tripId == tripId }
        val tripSettlements = _settlements.value.filter { it.tripId == tripId }

        val paidMap = mutableMapOf<String, Long>()
        val owedMap = mutableMapOf<String, Long>()

        trip.members.forEach { m ->
            paidMap[m.id] = 0L
            owedMap[m.id] = 0L
        }

        // Expenses
        for (exp in tripExpenses) {
            paidMap[exp.payerId] = (paidMap[exp.payerId] ?: 0L) + exp.amountPaise
            for (split in exp.splits) {
                owedMap[split.memberId] = (owedMap[split.memberId] ?: 0L) + split.amountPaise
            }
        }

        // Settlements adjust balances: "fromMember" paid "toMember"
        // so "fromMember" paid more, and "toMember" received money (reducing their paid credit)
        for (s in tripSettlements) {
            paidMap[s.fromMemberId] = (paidMap[s.fromMemberId] ?: 0L) + s.amountPaise
            paidMap[s.toMemberId] = (paidMap[s.toMemberId] ?: 0L) - s.amountPaise
        }

        return trip.members.map { member ->
            val paid = paidMap[member.id] ?: 0L
            val owed = owedMap[member.id] ?: 0L
            MemberBalance(
                memberId = member.id,
                memberName = member.name,
                totalPaidPaise = paid,
                totalOwedPaise = owed,
                netBalancePaise = paid - owed
            )
        }
    }

    fun computeDebtTransfers(tripId: String): List<DebtTransfer> {
        val balances = computeMemberBalances(tripId)
        val creditors = mutableListOf<Pair<MemberBalance, Long>>() // balance > 0
        val debtors = mutableListOf<Pair<MemberBalance, Long>>()   // balance < 0

        for (b in balances) {
            if (b.netBalancePaise > 0) {
                creditors.add(Pair(b, b.netBalancePaise))
            } else if (b.netBalancePaise < 0) {
                debtors.add(Pair(b, -b.netBalancePaise))
            }
        }

        val transfers = mutableListOf<DebtTransfer>()
        var cIdx = 0
        var dIdx = 0

        while (cIdx < creditors.size && dIdx < debtors.size) {
            val (creditor, cRem) = creditors[cIdx]
            val (debtor, dRem) = debtors[dIdx]

            val settle = min(cRem, dRem)
            if (settle > 0) {
                transfers.add(
                    DebtTransfer(
                        fromMemberId = debtor.memberId,
                        fromMemberName = debtor.memberName,
                        toMemberId = creditor.memberId,
                        toMemberName = creditor.memberName,
                        amountPaise = settle
                    )
                )
            }

            val newCRem = cRem - settle
            val newDRem = dRem - settle

            if (newCRem == 0L) cIdx++ else creditors[cIdx] = Pair(creditor, newCRem)
            if (newDRem == 0L) dIdx++ else debtors[dIdx] = Pair(debtor, newDRem)
        }

        return transfers
    }

    fun exportExpensesToCsv(tripId: String): String {
        val trip = _trips.value.find { it.id == tripId }
        val tripExpenses = _expenses.value.filter { it.tripId == tripId }
        val sb = StringBuilder()
        sb.append("Date,Title,Category,Amount_INR,Paid_By,Split_Type,Notes\n")
        for (exp in tripExpenses) {
            val safeTitle = "\"" + exp.title.replace("\"", "\"\"") + "\""
            val safeNotes = "\"" + exp.notes.replace("\"", "\"\"") + "\""
            val amt = String.format(Locale.US, "%.2f", exp.amountInRupees)
            sb.append("${exp.date},$safeTitle,${exp.category.enName},$amt,${exp.payerName},${exp.splitType.enLabel},$safeNotes\n")
        }
        return sb.toString()
    }

    // Memories (Strict Max 3 Photos per Place)
    fun addOrUpdateMemory(
        tripId: String,
        placeName: String,
        visitDate: String,
        personalStory: String,
        photoUris: List<String>,
        notes: String
    ): Result<TravelMemory> {
        if (photoUris.size > 3) {
            return Result.failure(IllegalArgumentException("Maximum 3 photos allowed per place."))
        }
        val existing = _memories.value.find { it.tripId == tripId && it.placeName.equals(placeName, ignoreCase = true) }
        val memory = if (existing != null) {
            existing.copy(
                visitDate = visitDate,
                personalStory = personalStory,
                photoUris = photoUris.take(3),
                notes = notes
            )
        } else {
            TravelMemory(
                tripId = tripId,
                placeName = placeName,
                visitDate = visitDate,
                personalStory = personalStory,
                photoUris = photoUris.take(3),
                notes = notes
            )
        }

        _memories.value = _memories.value.filter { it.id != memory.id } + memory
        return Result.success(memory)
    }

    fun deleteMemory(memoryId: String) {
        _memories.value = _memories.value.filter { it.id != memoryId }
    }

    // Bookings
    fun addBooking(
        tripId: String,
        type: BookingType,
        provider: String,
        bookingReference: String,
        startDateTime: String,
        endDateTime: String,
        costRupees: Double,
        status: String = "Confirmed",
        notes: String = ""
    ): Booking {
        val b = Booking(
            tripId = tripId,
            type = type,
            provider = provider,
            bookingReference = bookingReference,
            startDateTime = startDateTime,
            endDateTime = endDateTime,
            costRupees = costRupees,
            status = status,
            notes = notes
        )
        _bookings.value = _bookings.value + b
        return b
    }

    fun deleteBooking(bookingId: String) {
        _bookings.value = _bookings.value.filter { it.id != bookingId }
    }

    // Packing Items
    fun togglePackingItem(itemId: String) {
        _packingItems.value = _packingItems.value.map {
            if (it.id == itemId) it.copy(isPacked = !it.isPacked) else it
        }
    }

    fun addPackingItem(tripId: String, category: String, itemName: String): PackingItem {
        val item = PackingItem(tripId = tripId, category = category, itemName = itemName, isPacked = false)
        _packingItems.value = _packingItems.value + item
        return item
    }

    fun deletePackingItem(itemId: String) {
        _packingItems.value = _packingItems.value.filter { it.id != itemId }
    }

    // Shared Notes
    fun addSharedNote(tripId: String, authorName: String, title: String, content: String): SharedNote {
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val note = SharedNote(tripId = tripId, authorName = authorName, title = title, content = content, dateUpdated = dateStr)
        _sharedNotes.value = _sharedNotes.value + note
        return note
    }

    fun deleteSharedNote(noteId: String) {
        _sharedNotes.value = _sharedNotes.value.filter { it.id != noteId }
    }

    // Auth / User profile simulation
    fun updateUserProfile(name: String, email: String, phone: String) {
        _currentUser.value = _currentUser.value.copy(name = name, email = email, phone = phone)
    }

    fun logout() {
        _currentUser.value = User(id = "guest", name = "Guest User", email = "")
    }

    fun login(email: String, name: String) {
        _currentUser.value = User(name = name.ifBlank { "Traveler" }, email = email)
    }
}
