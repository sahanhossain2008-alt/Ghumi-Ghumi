package com.example.data.model

import java.util.UUID

data class User(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val email: String,
    val phone: String = ""
)

data class TripMember(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val email: String = "",
    val isOwner: Boolean = false
)

data class Trip(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val destinations: String,
    val startDate: String,
    val endDate: String,
    val totalBudget: Double, // in INR (₹)
    val coverImageUrl: String = "",
    val inviteCode: String = generateInviteCode(destinations),
    val ownerId: String = "u_default",
    val members: List<TripMember> = listOf(
        TripMember(id = "u_default", name = "You (Trip Lead)", isOwner = true)
    ),
    val warningThresholdPercent: Int = 80
)

fun generateInviteCode(dest: String): String {
    val clean = dest.take(4).uppercase().filter { it.isLetter() }.padEnd(4, 'X')
    val rand = (1000..9999).random()
    return "GHUMI-$clean-$rand"
}

enum class DestinationCategory(val enName: String, val hiName: String) {
    MOUNTAINS("Mountains & Hill Stations", "पर्वत और हिल स्टेशन"),
    BEACHES("Beaches & Coastal", "समुद्र तट और तटीय"),
    HERITAGE("Heritage & Historical", "धरोहर और ऐतिहासिक"),
    NATURE("Nature & Wildlife", "प्रकृति और वन्यजीव"),
    RELIGIOUS("Religious & Spiritual", "धार्मिक और आध्यात्मिक"),
    CULTURAL("Cities & Cultural", "शहर और सांस्कृतिक")
}

data class Destination(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val state: String,
    val category: DestinationCategory,
    val description: String,
    val bestTimeToVisit: String,
    val highlights: List<String>,
    val isCustom: Boolean = false
)

enum class ItineraryStatus(val enLabel: String, val hiLabel: String) {
    PLANNED("Planned", "योजित"),
    VISITED("Visited", "घूम लिया"),
    SKIPPED("Skipped", "छोड़ दिया"),
    RESCHEDULED("Rescheduled", "स्थगित")
}

data class ItineraryItem(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String,
    val dayNumber: Int,
    val time: String,
    val title: String,
    val placeName: String,
    val notes: String = "",
    val status: ItineraryStatus = ItineraryStatus.PLANNED
)

enum class ExpenseCategory(val enName: String, val hiName: String, val iconName: String) {
    TRANSPORT("Transport", "परिवहन", "DirectionsBus"),
    ACCOMMODATION("Accommodation", "होटल / आवास", "Hotel"),
    FOOD("Food & Dining", "भोजन और पेय", "Restaurant"),
    TICKETS("Tickets & Sightseeing", "टिकट और प्रवेश", "ConfirmationNumber"),
    SHOPPING("Shopping", "खरीदारी", "ShoppingBag"),
    ACTIVITIES("Activities", "गतिविधियां", "Surfing"),
    OTHER("Other", "अन्य", "Receipt")
}

enum class SplitType(val enLabel: String, val hiLabel: String) {
    EQUAL("Equal Split", "बराबर"),
    EXACT("Custom Exact (₹)", "कस्टम राशि"),
    PERCENTAGE("Percentage (%)", "प्रतिशत")
}

data class ExpenseSplit(
    val memberId: String,
    val memberName: String,
    val amountPaise: Long, // paise precision to prevent float rounding
    val percentage: Double = 0.0
)

data class Expense(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String,
    val title: String,
    val amountPaise: Long, // precise total in paise (1 INR = 100 paise)
    val payerId: String,
    val payerName: String,
    val date: String,
    val category: ExpenseCategory,
    val splitType: SplitType,
    val splits: List<ExpenseSplit>,
    val receiptUri: String? = null,
    val notes: String = ""
) {
    val amountInRupees: Double get() = amountPaise / 100.0
}

data class Settlement(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String,
    val fromMemberId: String,
    val fromMemberName: String,
    val toMemberId: String,
    val toMemberName: String,
    val amountPaise: Long,
    val date: String,
    val notes: String = ""
) {
    val amountInRupees: Double get() = amountPaise / 100.0
}

data class DebtTransfer(
    val fromMemberId: String,
    val fromMemberName: String,
    val toMemberId: String,
    val toMemberName: String,
    val amountPaise: Long
) {
    val amountInRupees: Double get() = amountPaise / 100.0
}

data class MemberBalance(
    val memberId: String,
    val memberName: String,
    val totalPaidPaise: Long,
    val totalOwedPaise: Long,
    val netBalancePaise: Long // positive = gets back, negative = owes
) {
    val totalPaidRupees: Double get() = totalPaidPaise / 100.0
    val totalOwedRupees: Double get() = totalOwedPaise / 100.0
    val netBalanceRupees: Double get() = netBalancePaise / 100.0
}

data class TravelMemory(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String,
    val placeName: String,
    val visitDate: String,
    val personalStory: String,
    val photoUris: List<String> = emptyList(), // Maximum 3 strictly enforced
    val notes: String = ""
)

enum class BookingType(val enLabel: String, val hiLabel: String) {
    FLIGHT("Flight", "उड़ान"),
    TRAIN("Train", "ट्रेन"),
    BUS("Bus", "बस"),
    HOTEL("Hotel / Resort", "होटल / रिसॉर्ट"),
    HOMESTAY("Homestay", "होमस्टे"),
    CAR_RENTAL("Cab / Rental", "टैक्सी / रेंटल"),
    OTHER("Other Booking", "अन्य बुकिंग")
}

data class Booking(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String,
    val type: BookingType,
    val provider: String,
    val bookingReference: String, // PNR or Reservation Code
    val startDateTime: String,
    val endDateTime: String,
    val costRupees: Double,
    val status: String = "Confirmed",
    val notes: String = ""
)

data class PackingItem(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String,
    val category: String, // Clothes, Documents, Toiletries, Electronics, First Aid, Custom
    val itemName: String,
    val isPacked: Boolean = false
)

data class SharedNote(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String,
    val authorName: String,
    val title: String,
    val content: String,
    val dateUpdated: String
)
